"""One-command local launcher. Never touches the older SH sourcing application."""
from pathlib import Path
import hashlib
import os
import shutil
import subprocess
import sys
import time
import urllib.request
import json
import webbrowser

ROOT=Path(__file__).resolve().parent


def run(command,**kw):
    subprocess.run([str(x) for x in command],check=True,cwd=ROOT,**kw)


def main():
    if sys.version_info<(3,11): raise RuntimeError('Python 3.11 이상이 필요합니다. Python 3.12를 권장합니다.')
    os.chdir(ROOT)
    python=ROOT/'.venv'/('Scripts/python.exe' if os.name=='nt' else 'bin/python')
    if not python.exists():
        print('[1/3] 전용 Python 실행 환경을 만듭니다.',flush=True)
        run([sys.executable,'-m','venv',ROOT/'.venv'])
    requirements=ROOT/'backend'/'requirements.lock'
    fingerprint=hashlib.sha256(requirements.read_bytes()).hexdigest()
    marker=ROOT/'.venv'/'.sh-installed'
    if not marker.exists() or marker.read_text()!=fingerprint:
        print('[1/3] Python 의존성을 설치합니다. 최초 실행에는 인터넷이 필요합니다.',flush=True)
        run([python,'-m','pip','install','-r',requirements,'--cache-dir',ROOT/'data'/'pip-cache'])
        marker.write_text(fingerprint)
    dist=ROOT/'frontend'/'dist'/'index.html'
    if not dist.exists():
        npm=shutil.which('npm.cmd' if os.name=='nt' else 'npm')
        node=shutil.which('node')
        if not npm or not node: raise RuntimeError('화면을 빌드하려면 Node.js 22.12 이상이 필요합니다. 배포 ZIP에는 빌드된 화면이 포함됩니다.')
        print('[2/3] 관리자 화면을 빌드합니다.',flush=True)
        subprocess.run([npm,'ci','--cache',str(ROOT/'data'/'npm-cache'),'--no-audit','--no-fund'],cwd=ROOT/'frontend',check=True)
        subprocess.run([npm,'run','build'],cwd=ROOT/'frontend',check=True)
    if not (ROOT/'.env').exists(): shutil.copyfile(ROOT/'.env.example',ROOT/'.env')
    # Only nonsecret port is read by the launcher. dotenv itself loads on the server.
    port=os.environ.get('SH_PORT','8765')
    if 'SH_PORT' not in os.environ:
        for line in (ROOT/'.env').read_text(encoding='utf-8-sig').splitlines():
            if line.strip().startswith('SH_PORT='): port=line.split('=',1)[1].strip().strip('"\'')
    if not port.isdigit() or not 1024<=int(port)<=65535: raise RuntimeError('SH_PORT는 1024~65535 정수여야 합니다.')
    url=f'http://127.0.0.1:{port}'
    def ready():
        try:
            # Bypass configured external proxies only for the loopback request.
            opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
            with opener.open(url+'/api/health',timeout=1) as response: return json.load(response).get('service')=='SH Auto Seller'
        except Exception: return False
    if ready():
        print('SH Auto Seller가 이미 실행 중입니다. 브라우저를 엽니다.',flush=True)
        if '--no-browser' not in sys.argv: webbrowser.open(url)
        return
    print('[3/3] SH Auto Seller를 시작합니다. 종료하려면 이 창에서 Ctrl+C를 누르세요.',flush=True)
    env=dict(os.environ);env['SH_PORT']=port
    process=subprocess.Popen([str(python),'-m','uvicorn','app.main:app','--app-dir',str(ROOT/'backend'),'--host','127.0.0.1','--port',port],cwd=ROOT,env=env)
    try:
        for _ in range(80):
            if process.poll() is not None: raise RuntimeError('서버를 실행하지 못했습니다. 위 오류 또는 포트 중복 여부를 확인하세요.')
            if ready():
                print('실행 완료. 주소: '+url,flush=True)
                if '--no-browser' not in sys.argv: webbrowser.open(url)
                break
            time.sleep(.25)
        else: raise RuntimeError('서버 준비 시간이 초과되었습니다. 오류 내용을 확인하세요.')
        process.wait()
    except KeyboardInterrupt:
        print('\nSH Auto Seller를 종료합니다.',flush=True)
    finally:
        if process.poll() is None:
            process.terminate()
            try: process.wait(timeout=5)
            except subprocess.TimeoutExpired: process.kill();process.wait()
    if process.returncode not in {0,-15,-2,130,3221225786}: raise RuntimeError(f'서버가 종료되었습니다 (코드 {process.returncode}).')

if __name__=='__main__':
    try: main()
    except (RuntimeError,subprocess.CalledProcessError,OSError) as exc:
        print('\n실행 실패: '+str(exc)+'\nREADME.md의 문제 해결 안내를 확인하세요.',file=sys.stderr)
        sys.exit(1)
