﻿실행 방법
1. ZIP 전체를 C:\SH 에 압축 해제하세요.
2. SH_Auto_Seller 폴더에서 START_WINDOWS.bat을 실행하세요.
3. Python 3.12가 설치되어 있어야 합니다.
문제가 계속되면 Windows에 표시되는 오류 문구를 알려주세요.
