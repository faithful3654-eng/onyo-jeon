﻿Windows 설치 수정본 v1.0.1
1. Python 3.12 64비트를 설치하세요. 다른 Python은 그대로 두어도 됩니다.
공식 설치 파일: https://www.python.org/ftp/python/3.12.10/python-3.12.10-amd64.exe
2. 이 ZIP 전체를 새 폴더에 압축 해제하세요.
3. SH_Auto_Seller 폴더의 START_WINDOWS.bat을 실행하세요.
설치용 wheel 25개를 포함하며 Rust/Visual Studio 컴파일 없이 설치합니다.
기존 사용 자료는 원래 폴더의 data에 있으므로 기존 폴더는 보관하세요.
