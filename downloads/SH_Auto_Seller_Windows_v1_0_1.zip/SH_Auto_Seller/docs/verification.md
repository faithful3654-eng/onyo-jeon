# 1차 MVP 검증 결과

검증일: 2026-10-21 (한국 시간).

- FastAPI/계산/SQLite/파일 API 테스트: **21 passed**.
- 실제 Chromium 브라우저 테스트: **2 passed**. 전체 입력·재열기·매핑·가져오기·마진·설정·백업·승인 삭제와 390px 좁은 화면 검증.
- TypeScript 검사 및 Vite 프로덕션 빌드: 성공.
- launcher.py --no-browser: 의존성 설치 확인, FastAPI 서버 시작, /api/health 정상, 실제 화면 HTTP 응답 확인.
- 기존 SH 꿀통소싱 앱 테스트: 별도 **22 passed**.
- 개발 중 발견한 매핑/모바일 접근성 이름과 추가 열 데이터 처리 문제 수정 후 전체 테스트 재통과.
- 제3자 AnyIO BlockingPortal 사용 중단 예정 경고 1건은 남아 있으나 테스트 실패는 아님.

실제 Windows OS 및 배치 파일의 Windows 실행, 외부 API/AI/QAPI 통합은 미검증. API는 1차 범위에서 미구현이며 실제 등록 요청 없음.

첨부 화면은 브라우저 테스트의 비어 있는 대시보드와 가상 비용 예시입니다. 실제 판매 데이터나 공급 견적이 아닙니다.

## Windows 설치 수정 v1.0.1

- Python 3.12 x64 자동 선택, 비호환 가상환경 백업 후 재생성.
- 모든 설치에 binary-only 옵션 적용, Windows에는 해시 검증한 wheel 25개 포함.
- 25개 wheel의 SHA-256을 공식 PyPI 릴리스 메타데이터와 전부 대조해 일치 확인.
- pip의 Windows CPython 3.12 x64 대상 오프라인 의존성 해결 및 해시 검증 통과.
- Windows OS 자체 실행은 여전히 미검증. 스크린샷의 소스 빌드 실패를 우회하지 않고, 호환 런타임과 사전 빌드 파일만 사용하도록 변경.
