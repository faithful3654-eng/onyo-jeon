"""Future official supplier adapters must return validated Product objects.
No network access is made in the phase-1 MVP.
"""
from typing import Protocol
from .models import Product

class SupplierAdapter(Protocol):
    name: str
    def collect(self,url:str)->list[Product]: ...

REGISTRY: dict[str,SupplierAdapter]={}

def capabilities():
    return {'manual':True,'excel':True,'csv':True,'supplier_api':False,'url_collection':False,
            'openai':False,'gemini':False,'qapi':False,'qsm_export':False,'dry_run':True,
            'message':'1차 MVP: 외부 수집·AI·QAPI 미연결. URL은 원본 출처로만 저장하며 내용을 읽지 않습니다.'}
