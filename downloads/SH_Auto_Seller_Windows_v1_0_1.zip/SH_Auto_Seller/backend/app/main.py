from pathlib import Path
from collections import defaultdict, deque
from time import monotonic
from io import BytesIO
import json
import os
import tempfile
import uuid
from urllib.parse import urlsplit
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Request, UploadFile, File
from fastapi.responses import FileResponse, Response, JSONResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.trustedhost import TrustedHostMiddleware
from .db import Database, Conflict, Missing
from .models import Product, ProductUpdate, DeleteRequest, Settings, MarginInput, PreviewRequest, CommitRequest, FIELDS, now
from .margin import calculate
from .files import parse_file, preview, commit, product_export, tabular, MAX_FILE
from .connectors import capabilities

ROOT=Path(__file__).resolve().parents[2]
load_dotenv(ROOT/'.env',override=False)


def create_app(db_path=None):
    db_setting=Path(os.environ.get('SH_DB_PATH','data/sh_auto_seller.sqlite3'))
    db=Database(db_path or (db_setting if db_setting.is_absolute() else ROOT/db_setting))
    app=FastAPI(title='SH Auto Seller',version='1.0.0',docs_url='/api/docs',redoc_url=None,openapi_url='/api/openapi.json')
    app.state.db=db
    app.add_middleware(TrustedHostMiddleware,allowed_hosts=['127.0.0.1','localhost','testserver'])
    buckets=defaultdict(deque)
    @app.middleware('http')
    async def local_guard(request:Request,call_next):
        origin=request.headers.get('origin')
        if origin:
            parsed=urlsplit(origin)
            if parsed.hostname not in {'localhost','127.0.0.1'} or parsed.scheme!='http' or parsed.port not in {5173,8765,int(os.environ.get('SH_PORT','8765'))}:
                return JSONResponse({'detail':'로컬 관리자 화면에서만 요청할 수 있습니다'},status_code=403)
        if request.url.path.startswith('/api'):
            key=(request.client.host if request.client else 'local',request.method=='GET')
            bucket=buckets[key]; t=monotonic()
            while bucket and t-bucket[0]>60: bucket.popleft()
            if len(bucket)>=(600 if key[1] else 120): return JSONResponse({'detail':'요청이 많습니다. 잠시 후 다시 시도하세요'},status_code=429,headers={'Retry-After':'60'})
            bucket.append(t)
        response=await call_next(request)
        response.headers['X-Content-Type-Options']='nosniff'
        response.headers['Referrer-Policy']='no-referrer'
        if request.url.path.startswith('/api'): response.headers['Cache-Control']='no-store'
        return response
    @app.exception_handler(Conflict)
    async def conflict(request,exc): return JSONResponse({'detail':str(exc)},status_code=409)
    @app.exception_handler(Missing)
    async def missing(request,exc): return JSONResponse({'detail':str(exc)},status_code=404)
    @app.exception_handler(ValueError)
    async def invalid(request,exc): return JSONResponse({'detail':str(exc)},status_code=422)

    @app.get('/api/health')
    def health(): return {'status':'ok','service':'SH Auto Seller','phase':1}
    @app.get('/api/capabilities')
    def caps(): return capabilities()
    @app.get('/api/products')
    def products(q:str=''):
        rows=db.list()
        if q: rows=[p for p in rows if q.casefold() in ' '.join(str(p.get(k,'')) for k in ['name','sku','brand','supplier']).casefold()]
        return rows
    @app.post('/api/products',status_code=201)
    def create_product(product:Product): return db.create(product)
    @app.get('/api/products/{pid}')
    def get_product(pid:str): return db.get(pid)
    @app.put('/api/products/{pid}')
    def update_product(pid:str,body:ProductUpdate): return db.update(pid,body.product,body.expected_version)
    @app.delete('/api/products/{pid}')
    def delete_product(pid:str,body:DeleteRequest):
        if not body.approved: raise HTTPException(403,'판매자 삭제 승인이 필요합니다')
        db.delete(pid,body.expected_version); return {'deleted':True}
    @app.get('/api/settings')
    def settings(): return db.settings()
    @app.put('/api/settings')
    def save_settings(body:Settings):
        if body.platform_fee_pct is not None and body.platform_fee_pct+body.target_margin_pct>=100: raise ValueError('수수료율과 목표 이익률 합계는 100% 미만')
        return db.settings(body)
    @app.post('/api/margin')
    def margin(body:MarginInput): return calculate(body)
    @app.get('/api/dashboard')
    def dashboard():
        rows=db.list()
        return dict(total=len(rows),missing_cost=sum(p['purchase_krw'] is None or p['domestic_shipping_krw'] is None for p in rows),
                    no_image_rights=sum(not p['image_rights_confirmed'] for p in rows),states={'수집 완료':len(rows),'분석 완료':0,'번역 완료':0,'검토 필요':0,'등록 대기':0,'등록 완료':0,'등록 실패':0},recent=rows[:5])
    @app.get('/api/fields')
    def fields(): return FIELDS
    @app.post('/api/imports/inspect')
    async def inspect(file:UploadFile=File(...)):
        content=await file.read(MAX_FILE+1)
        try: sheets=parse_file(file.filename or '',content)
        except ValueError: raise
        except Exception as e: raise HTTPException(422,'파일을 읽을 수 없습니다. 손상·암호화 여부와 파일 형식을 확인하세요') from e
        uid=uuid.uuid4().hex
        with db.connect() as con: con.execute('INSERT INTO uploads VALUES(?,?,?)',(uid,json.dumps(sheets,ensure_ascii=False),now()))
        return dict(upload_id=uid,sheets={name:dict(headers=s['headers'],sample=s['rows'][:5],count=len(s['rows']),suggested_mapping=s['suggested_mapping']) for name,s in sheets.items()})
    @app.post('/api/imports/preview')
    def import_preview(body:PreviewRequest): return preview(db,body)
    @app.post('/api/imports/commit')
    def import_commit(body:CommitRequest):
        if not body.approved: raise HTTPException(403,'유효 행 가져오기 승인이 필요합니다')
        return commit(db,body.batch_id)
    @app.get('/api/imports/{batch_id}/report')
    def report(batch_id:str):
        with db.connect() as con: b=con.execute('SELECT * FROM batches WHERE id=?',(batch_id,)).fetchone()
        if not b: raise Missing('검증 결과가 없습니다')
        rows=json.loads(b['body'])
        blob=tabular(['원본 행','검증결과','실제반영','SKU','오류'],[[r['row'],r['action'],'반영' if b['state']=='committed' and r['action']!='오류' else '미반영',(r['product'] or {}).get('sku',''),'; '.join(r['errors'])] for r in rows],'csv')
        return Response(blob,media_type='text/csv; charset=utf-8',headers={'Content-Disposition':'attachment; filename="import_report.csv"'})
    @app.get('/api/export/{fmt}')
    def export(fmt:str):
        if fmt not in {'csv','xlsx'}: raise HTTPException(404,'지원하지 않는 형식')
        return Response(product_export(db.list(),fmt),media_type='text/csv; charset=utf-8' if fmt=='csv' else 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',headers={'Content-Disposition':f'attachment; filename="SH_products.{fmt}"'})
    @app.get('/api/template/{fmt}')
    def template(fmt:str):
        if fmt not in {'csv','xlsx'}: raise HTTPException(404,'지원하지 않는 형식')
        return Response(tabular(list(FIELDS.values()),[],fmt),media_type='text/csv; charset=utf-8' if fmt=='csv' else 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',headers={'Content-Disposition':f'attachment; filename="SH_template.{fmt}"'})
    @app.get('/api/backup')
    def backup():
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'backup.sqlite3'; db.backup(path); blob=path.read_bytes()
        return Response(blob,media_type='application/octet-stream',headers={'Content-Disposition':'attachment; filename="SH_Auto_Seller_backup.sqlite3"'})
    dist=ROOT/'frontend'/'dist'
    if dist.exists():
        app.mount('/assets',StaticFiles(directory=dist/'assets'),name='assets')
        @app.get('/')
        def index(): return FileResponse(dist/'index.html',headers={'Cache-Control':'no-cache'})
    return app

app=create_app()
