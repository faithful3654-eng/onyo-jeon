from io import BytesIO
import json
import sqlite3
import pytest
from fastapi.testclient import TestClient
from openpyxl import Workbook, load_workbook
from app.main import create_app
from app.models import MarginInput
from app.margin import calculate

@pytest.fixture
def client(tmp_path):
    with TestClient(create_app(tmp_path/'db.sqlite3')) as c: yield c


def product(**kw): return dict(name='테스트 고무장갑',purchase_krw=5000,domestic_shipping_krw=1000,**kw)

def complete(**kw):
    d=dict(purchase_krw=5000,domestic_shipping_krw=1000,international_shipping_krw=3000,packaging_krw=500,
           tax_other_krw=0,return_reserve_krw=500,exchange_krw_per_100_jpy=1000,platform_fee_pct=10,
           seller_coupon_jpy=100,buyer_shipping_jpy=500,target_margin_pct=25,sale_jpy=3000)
    d.update(kw); return MarginInput(**d)


def test_margin_revenue_coupon_shipping_and_rounding():
    r=calculate(complete())
    assert r['revenue_krw']==35000
    assert r['total_cost_krw']==14500
    assert r['contribution_krw']==20500
    # (10,000 + 1,000 + 500 - 5,000*0.75) / (10*0.65), rounded up.
    assert r['recommended_jpy']==1193
    at_price=calculate(complete(sale_jpy=r['recommended_jpy']))
    below=calculate(complete(sale_jpy=r['recommended_jpy']-1))
    assert at_price['margin_pct']>=25 and below['margin_pct']<25
    break_price=r['breakeven_jpy']
    assert calculate(complete(sale_jpy=break_price))['contribution_krw']>=0
    assert calculate(complete(sale_jpy=break_price-1))['contribution_krw']<0


def test_margin_fee_settlement_and_free_shipping():
    paid=calculate(complete(settlement='상품만 수수료'))
    assert paid['total_cost_krw']==14000
    free=calculate(complete(paid_shipping=False,buyer_shipping_jpy=0))
    assert free['shipping_no'] is None
    assert free['revenue_krw']==30000
    with pytest.raises(ValueError): calculate(complete(paid_shipping=False,buyer_shipping_jpy=1))


def test_missing_cost_and_invalid_margin(client):
    for field in ['international_shipping_krw','platform_fee_pct','return_reserve_krw','exchange_krw_per_100_jpy']:
        r=calculate(complete(**{field:None}))
        assert field in r['missing']
        assert r['recommended_jpy'] is None and r['contribution_krw'] is None
    r=client.post('/api/margin',json=complete(platform_fee_pct=80).model_dump())
    assert r.status_code==422
    assert client.post('/api/margin',json={'exchange_krw_per_100_jpy':0}).status_code==422


def test_crud_duplicate_approval_and_version(client):
    p=client.post('/api/products',json=product(source_url='https://example.com/p/',options='M')).json()
    assert p['sku'].startswith('SH-') and p['workflow_status']=='수집 완료'
    assert client.post('/api/products',json=product(source_url='https://example.com/p#top',options='m')).status_code==409
    assert client.post('/api/products',json=product(source_url='https://example.com/p',options='L')).status_code==201
    data={k:v for k,v in p.items() if k not in {'id','version','updated_at','workflow_status'}}; data['name']='수정된 장갑'
    r=client.put('/api/products/'+p['id'],json={'product':data,'expected_version':1})
    assert r.json()['version']==2
    assert client.put('/api/products/'+p['id'],json={'product':data,'expected_version':1}).status_code==409
    assert client.request('DELETE','/api/products/'+p['id'],json={'approved':False,'expected_version':2}).status_code==403
    assert client.request('DELETE','/api/products/'+p['id'],json={'approved':True,'expected_version':1}).status_code==409
    assert client.request('DELETE','/api/products/'+p['id'],json={'approved':True,'expected_version':2}).status_code==200
    assert client.get('/api/products/'+p['id']).status_code==404


@pytest.mark.parametrize('field,value',[('purchase_krw',-1),('stock',1.2),('stock',True),('source_url','https://a:b@example.com'),('source_url','https://example.com?token=secret'),('collected_at','nonsense'),('image_urls',['javascript:alert(1)']),('name','')])
def test_invalid_product(client,field,value):
    d=product();d[field]=value
    assert client.post('/api/products',json=d).status_code==422


def inspect_csv(client,text):
    r=client.post('/api/imports/inspect',files={'file':('data.csv',text.encode('utf-8-sig'),'text/csv')})
    assert r.status_code==200,r.text
    return r.json()

def preview_csv(client,text,mapping,merge=False):
    up=inspect_csv(client,text)
    r=client.post('/api/imports/preview',json={'upload_id':up['upload_id'],'sheet':'CSV','mapping':mapping,'merge':merge})
    assert r.status_code==200,r.text
    return r.json()


def test_import_mapping_errors_commit_idempotency_and_merge(client):
    text='코드,이름,가격,재고\nA01,고무장갑,"5,000",20\nA01,중복,2000,10\nA02,오류,abc,5\nA03,장갑 L,,\n'
    mapping={'sku':'코드','name':'이름','purchase_krw':'가격','stock':'재고'}
    p=preview_csv(client,text,mapping)
    assert p['valid']==2 and p['errors']==2
    assert client.post('/api/imports/commit',json={'batch_id':p['batch_id']}).status_code==403
    r=client.post('/api/imports/commit',json={'batch_id':p['batch_id'],'approved':True})
    assert r.json()['inserted']==2 and r.json()['skipped']==2
    assert client.post('/api/imports/commit',json={'batch_id':p['batch_id'],'approved':True}).json()==r.json()
    assert len(client.get('/api/products').json())==2
    update=preview_csv(client,'코드,이름\nA01,갱신\n',{'sku':'코드','name':'이름'},True)
    assert client.post('/api/imports/commit',json={'batch_id':update['batch_id'],'approved':True}).json()['updated']==1
    saved=next(p for p in client.get('/api/products').json() if p['sku']=='A01')
    assert saved['name']=='갱신' and saved['purchase_krw']==5000 and saved['stock']==20
    report=client.get('/api/imports/'+p['batch_id']+'/report')
    assert '오류' in report.content.decode('utf-8-sig')


def test_import_stale_update_is_atomic(client):
    client.post('/api/products',json=product(sku='A01'))
    p=preview_csv(client,'코드,이름\nNEW01,신규\nA01,병합\n',{'sku':'코드','name':'이름'},True)
    existing=client.get('/api/products').json()[0]
    d={k:v for k,v in existing.items() if k not in {'id','version','updated_at','workflow_status'}}
    client.put('/api/products/'+existing['id'],json={'product':d,'expected_version':1})
    assert client.post('/api/imports/commit',json={'batch_id':p['batch_id'],'approved':True}).status_code==409
    assert len(client.get('/api/products').json())==1


def test_xlsx_sheet_selection_aliases_and_original_unchanged(client):
    wb=Workbook();wb.active.title='안내';wb.active.append(['설명']);wb.active.append(['안내만 있는 시트'])
    ws=wb.create_sheet('공급상품');ws.append(['상품명','매입가','옵션별 재고']);ws.append(['니트릴',4500,30])
    out=BytesIO();wb.save(out); original=out.getvalue()
    up=client.post('/api/imports/inspect',files={'file':('data.xlsx',original)}).json()
    assert set(up['sheets'])=={'안내','공급상품'}
    m=up['sheets']['공급상품']['suggested_mapping']
    p=client.post('/api/imports/preview',json={'upload_id':up['upload_id'],'sheet':'공급상품','mapping':m}).json()
    assert p['valid']==1
    client.post('/api/imports/commit',json={'batch_id':p['batch_id'],'approved':True})
    assert client.get('/api/products').json()[0]['stock']==30
    assert out.getvalue()==original


def test_formula_injection_and_malformed_upload(client):
    p=preview_csv(client,'상품명,매입가\n=HYPERLINK("x"),10\n',{'name':'상품명','purchase_krw':'매입가'})
    assert p['errors']==1
    client.post('/api/products',json=product(notes='=HYPERLINK("bad")'))
    csvdata=client.get('/api/export/csv').content.decode('utf-8-sig')
    assert "'=HYPERLINK" in csvdata
    assert client.post('/api/imports/inspect',files={'file':('bad.xlsx',b'not an excel')}).status_code==422
    assert client.post('/api/imports/inspect',files={'file':('bad.csv',b'name,name\na,b')}).status_code==422


def test_settings_backup_restore_and_no_keys(client,tmp_path):
    client.post('/api/products',json=product())
    s=client.get('/api/settings').json(); s['exchange_krw_per_100_jpy']=950
    assert client.put('/api/settings',json=s).json()['exchange_krw_per_100_jpy']==950
    blob=client.get('/api/backup').content
    path=tmp_path/'restored.sqlite3';path.write_bytes(blob)
    restored=TestClient(create_app(path))
    assert len(restored.get('/api/products').json())==1
    assert restored.get('/api/settings').json()['exchange_krw_per_100_jpy']==950
    assert 'API_KEY' not in str(client.get('/api/settings').json())
    caps=client.get('/api/capabilities').json()
    assert caps['dry_run'] and not caps['qapi'] and not caps['openai']


def test_local_origin_and_unknown_field_guard(client):
    assert client.post('/api/products',json=product(),headers={'Origin':'https://evil.example'}).status_code==403
    assert client.post('/api/products',json=dict(product(),api_key='never')).status_code==422
    assert client.get('/api/health',headers={'Host':'evil.example'}).status_code==400


def test_export_template_and_reload_database(client):
    client.post('/api/products',json=product(sku='S01'))
    for fmt in ['csv','xlsx']:
        assert client.get('/api/template/'+fmt).status_code==200
        data=client.get('/api/export/'+fmt)
        assert data.status_code==200 and len(data.content)>30
    assert len(TestClient(create_app(client.app.state.db.path)).get('/api/products').json())==1


def test_product_identity_retains_business_query_but_drops_tracking(client):
    assert client.post('/api/products',json=product(source_url='https://example.com/item?goodsNo=1&utm_source=test')).status_code==201
    assert client.post('/api/products',json=product(source_url='https://example.com/item?goodsNo=1')).status_code==409
    assert client.post('/api/products',json=product(source_url='https://example.com/item?goodsNo=2')).status_code==201


def test_unlabelled_import_cells_are_rejected(client):
    assert client.post('/api/imports/inspect',files={'file':('extra.csv',b'name\nA,B\n')}).status_code==422
