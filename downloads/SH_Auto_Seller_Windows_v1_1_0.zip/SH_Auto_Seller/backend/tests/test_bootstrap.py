from pathlib import Path
import importlib.util
import sys
import pytest

ROOT=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('bootstrap',ROOT/'bootstrap.py')
bootstrap=importlib.util.module_from_spec(spec);spec.loader.exec_module(bootstrap)


def profile(version=(3,12),bits=64,platform='win-amd64'):
    return dict(version=list(version),bits=bits,platform=platform,implementation='cpython',executable='C:/Python312/python.exe')


@pytest.mark.parametrize('info',[profile((3,15)),profile((3,14)),profile((3,12),32,'win32'),profile((3,12),64,'win-arm64'),None])
def test_unsupported_windows_runtime_is_not_used(info):
    assert not bootstrap.supported(info,True)


def test_selects312_instead_of_latest_and_rejects32bit():
    attempts=[]
    def probe(command):
        attempts.append(command)
        return profile(bits=32,platform='win32') if command==['py','-3.12-64'] else profile()
    assert bootstrap.find_windows_python(probe)=='C:/Python312/python.exe'
    assert attempts==[['py','-3.12-64'],['py','-3.12']]
    assert bootstrap.find_windows_python(lambda _:None) is None


def test_broken_venv_is_backed_up_without_touching_data(tmp_path):
    old=tmp_path/'.venv';(old/'Scripts').mkdir(parents=True)
    (old/'Scripts/python.exe').write_text('old python')
    (old/'old-package.txt').write_text('preserve this')
    data=tmp_path/'data';data.mkdir();(data/'user.sqlite3').write_bytes(b'user data')
    def create(command,**kwargs):
        dest=Path(command[-1]);(dest/'Scripts').mkdir(parents=True);(dest/'Scripts/python.exe').write_text('new python')
    runtime=bootstrap.ensure_venv(tmp_path,'C:/Python312/python.exe',windows=True,probe=lambda _:profile((3,15)),runner=create)
    backups=list(tmp_path.glob('.venv-backup-*'))
    assert len(backups)==1 and (backups[0]/'old-package.txt').read_text()=='preserve this'
    assert runtime.read_text()=='new python'
    assert (data/'user.sqlite3').read_bytes()==b'user data'


def test_compatible_venv_is_reused(tmp_path):
    exe=tmp_path/'.venv/Scripts/python.exe';exe.parent.mkdir(parents=True);exe.write_text('usable')
    def fail(*args,**kwargs): pytest.fail('Should not recreate a valid environment')
    assert bootstrap.ensure_venv(tmp_path,'creator',windows=True,probe=lambda _:profile(),runner=fail)==exe


def test_installer_never_compiles_and_uses_hash_checked_offline_wheels(tmp_path):
    (tmp_path/'backend').mkdir();(tmp_path/'backend/requirements-windows.lock').write_text('pydantic_core==2.41.4 --hash=sha256:abc\n')
    (tmp_path/'windows_wheels').mkdir()
    command,fingerprint=bootstrap.install_plan(tmp_path,'python.exe',windows=True)
    assert '--only-binary=:all:' in command
    assert '--require-hashes' in command and '--no-index' in command and '--find-links' in command
    assert len(fingerprint)==64
    before=fingerprint
    (tmp_path/'backend/requirements-windows.lock').write_text('changed')
    assert bootstrap.install_plan(tmp_path,'python.exe',windows=True)[1]!=before


def test_bundled_wheels_match_manifest_and_tampering_is_rejected(tmp_path):
    import hashlib,json,shutil,subprocess
    wheels=ROOT/'windows_wheels'
    if not wheels.exists(): pytest.skip('Wheelhouse is included in the Windows distribution')
    manifest=json.loads((wheels/'SHA256SUMS.json').read_text())
    assert len(manifest)==25
    for entry in manifest:
        assert hashlib.sha256((wheels/entry['file']).read_bytes()).hexdigest()==entry['sha256']
    core=next(entry for entry in manifest if entry['file'].startswith('pydantic_core-'))
    assert core['file'].endswith('-cp312-cp312-win_amd64.whl')
    bad=tmp_path/'wheels';bad.mkdir();(bad/core['file']).write_bytes((wheels/core['file']).read_bytes()+b'corruption')
    lock=tmp_path/'requirements.txt'
    lock.write_text('pydantic-core==2.41.4 --hash=sha256:'+core['sha256']+'\n')
    run=subprocess.run([sys.executable,'-m','pip','download','--disable-pip-version-check','--no-deps','--only-binary=:all:',
        '--platform','win_amd64','--python-version','3.12','--implementation','cp','--abi','cp312','--require-hashes',
        '--no-index','--find-links',str(bad),'--dest',str(tmp_path/'output'),'-r',str(lock)],capture_output=True,text=True)
    assert run.returncode!=0
    assert 'HASHES' in run.stderr
