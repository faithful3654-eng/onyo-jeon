from datetime import datetime,timedelta,timezone
from pathlib import Path
from email.message import EmailMessage
from xml.etree import ElementTree as ET
import json,ssl,sqlite3
import pytest
from fastapi.testclient import TestClient
from app.db import Database
from app.main import create_app
from app.reports import ReportService,ReportSettingsUpdate,render_report
from app.research import PublicResearch,product_facts,ranking_links,Unavailable,SameSiteRedirect
from app.report_mail import send_message,DeliveryUnknown
from app.report_schedule import task_xml,NS

class FakeVault:
    def __init__(self):self.secret=''
    def get(self):return self.secret
    def has(self):return bool(self.secret)
    def put(self,secret):self.secret=secret
    def clear(self):self.secret=''


def product_page(origin='韓国',category='生活用品',name='ニトリル手袋',sales=True,review=99999):
    obj={'@type':'Product','name':name,'category':category,'offers':{'price':2000,'priceCurrency':'JPY'},'aggregateRating':{'reviewCount':review}}
    facts=f'<dl><dt>発送国</dt><dd>{origin}</dd>'
    if sales:facts+='<dt>販売数</dt><dd>120個</dd><dt>販売期間</dt><dd>2026-09</dd>'
    return '<script type="application/ld+json">'+json.dumps(obj)+'</script>'+facts+'</dl>'


def fake_research(pages=None):
    pages=pages or {'https://www.qoo10.jp/g/12345678':product_page()}
    ranking=''.join(f'<a href="{url}">商品</a>' for url in pages)
    def fetch(url):
        if url.endswith('robots.txt'):return 'User-agent: *\nAllow: /\n'
        if '/Bestsellers/' in url:return ranking
        return pages[url]
    return PublicResearch(fetcher=fetch,pause=lambda _:None)


def test_public_research_filters_country_and_excluded_categories_without_inventing_sales():
    pages={'https://www.qoo10.jp/g/12345678':product_page(sales=False),
           'https://www.qoo10.jp/g/12345679':product_page(category='アダルト'),
           'https://www.qoo10.jp/g/12345680':product_page(origin='日本')}
    result=fake_research(pages).collect(True,1000)
    assert len(result['candidates'])==1 and result['verified_sales_count']==0
    row=result['candidates'][0]
    assert row['sales'] is None and row['review_count']==99999
    assert row['profit_status']=='수익성 추가 검증 필요'
    assert result['skipped']['제외분야 키워드 감지 · 검토 보류']==1
    assert result['skipped']['한국 발송 표기 미확인']==1
    assert any('1/10' in w for w in result['warnings'])


def test_country_in_description_does_not_prove_shipping_and_missing_category_is_held():
    page=product_page(origin='日本')+'<p>韓国から発送、韓国ブランド！</p>'
    row,error=product_facts(page,'https://www.qoo10.jp/g/12345678',1)
    assert row is None and error=='한국 발송 표기 미확인'
    row,error=product_facts(product_page(category=''),'https://www.qoo10.jp/g/12345678',1)
    assert row is None


def test_research_refuses_blocked_sources_and_does_not_fill_ten():
    def blocked(url):raise Unavailable('403 접근 불가')
    result=PublicResearch(fetcher=blocked,pause=lambda _:None).collect(True)
    assert result['candidates']==[] and any('403' in w for w in result['warnings'])
    result=PublicResearch(fetcher=lambda _:pytest.fail('No access before approval')).collect(False)
    assert result['candidates']==[]
    def robots(url):return 'User-agent: *\nDisallow: /\n'
    assert PublicResearch(fetcher=robots).collect(True)['candidates']==[]


def test_research_target_price_and_catalog_demo_filter():
    result=fake_research().collect(True,exchange=2000)
    assert not result['candidates'] # 2000JPY -> 40000KRW, above 39900.
    result=fake_research().collect(True,1000,[{'name':'ニトリル手袋','source_url':'https://example.com/demo','data_status':'데모'}])
    assert result['candidates'][0]['sourcing_url'] is None


def test_html_report_escapes_source_and_contains_clickable_links():
    result=fake_research().collect(True)
    result['candidates'][0]['name']='<script>alert(1)</script>'
    subject,text,html=render_report(result,'2026-10-21')
    assert '<script>' not in html and '&lt;script&gt;' in html
    assert '<a href="https://www.qoo10.jp/g/12345678">' in html
    assert '수익성 추가 검증 필요' in text


def test_task_xml_uses_korea_offset_user_token_and_separate_worker(tmp_path):
    clock=datetime(2026,10,21,23,30,tzinfo=timezone.utc) # 08:30 next day Korea.
    data=task_xml(tmp_path/'경로 공백','S-1-5-21-123','08:00',clock)
    root=ET.fromstring(data);ns={'t':NS}
    assert root.find('.//t:StartBoundary',ns).text=='2026-10-23T08:00:00+09:00'
    assert root.find('.//t:LogonType',ns).text=='InteractiveToken'
    assert root.find('.//t:Command',ns).text.endswith('python.exe')
    assert 'daily_report.py' in root.find('.//t:Arguments',ns).text
    assert root.find('.//t:MultipleInstancesPolicy',ns).text=='IgnoreNew'
    assert b'password' not in data.lower()


def test_smtp_uses_verified_tls_and_same_sender_recipient():
    captured={}
    class SMTP:
        def __init__(self,host,port,timeout,context):
            assert host=='smtp.naver.com' and port==465
            assert context.check_hostname and context.verify_mode==ssl.CERT_REQUIRED
        def __enter__(self):return self
        def __exit__(self,*args):pass
        def login(self,user,password):assert password=='private-test-value';captured['user']=user
        def send_message(self,msg):captured['message']=msg;return {}
    m=EmailMessage();m.set_content('test')
    send_message('tester@naver.com','private-test-value',m,SMTP)
    assert m['From']==m['To']=='tester@naver.com'
    assert 'private-test-value' not in m.as_string()


def test_ambiguous_delivery_is_not_retried():
    class SMTP:
        def __init__(self,*a,**k):pass
        def __enter__(self):return self
        def __exit__(self,*a):pass
        def login(self,*a):pass
        def send_message(self,*a):raise OSError('disconnect after DATA')
    with pytest.raises(DeliveryUnknown):send_message('tester@naver.com','secret',EmailMessage(),SMTP)


def service(tmp_path,mailer=None):
    vault=FakeVault();db=Database(tmp_path/'db.sqlite3')
    s=ReportService(db,tmp_path,vault,fake_research(),mailer or (lambda *a:None))
    s.save(ReportSettingsUpdate(account='tester@naver.com',password='private-test-value',public_access_approved=True))
    return s,vault


def test_daily_idempotence_and_secrets_not_in_api_backup_or_messages(tmp_path):
    sent=[];s,vault=service(tmp_path,lambda account,password,msg:sent.append(msg))
    public=s.public();assert public['password_set'] and 'password' not in public
    assert 'private-test-value' not in json.dumps(public)
    s.test_email();assert len(sent)==1
    run_id,fresh=s.claim('daily','2026-10-21');assert fresh
    s.perform(run_id,True);s.perform(run_id,True)
    assert len(sent)==2
    assert s.claim('daily','2026-10-21')==(run_id,False)
    assert s.runs()[0]['state']=='sent'
    backup=tmp_path/'backup.sqlite3';s.db.backup(backup)
    assert b'private-test-value' not in backup.read_bytes()
    s.save(ReportSettingsUpdate(account='replacement@naver.com',public_access_approved=True))
    assert not vault.has() and s.config()['mail_tested_at'] is None


def test_delivery_unknown_persists_without_automatic_resend(tmp_path):
    s,vault=service(tmp_path)
    s.test_email()
    calls=[]
    def unknown(*args):calls.append(1);raise DeliveryUnknown('발송 결과 미확인')
    s.mailer=unknown
    run_id,_=s.claim('daily');s.perform(run_id,True);s.perform(run_id,True)
    assert calls==[1] and s.runs()[0]['state']=='unknown'


def test_report_api_save_test_and_approval_guards(tmp_path):
    sent=[]
    app=create_app(tmp_path/'db.sqlite3',FakeVault(),fake_research(),lambda account,password,msg:sent.append(msg))
    c=TestClient(app)
    res=c.put('/api/reports/settings',json={'account':'tester@naver.com','password':'private-test-value','public_access_approved':True})
    assert res.status_code==200
    assert 'private-test-value' not in res.text
    assert c.post('/api/reports/test-email',json={'approved':False}).status_code==403
    assert c.post('/api/reports/test-email',json={'approved':True}).status_code==200
    assert len(sent)==1
    assert c.post('/api/reports/send-now',json={'approved':False}).status_code==403
    assert c.post('/api/reports/schedule/enable',json={'approved':False}).status_code==422
    import os
    if os.name!='nt':
        assert c.post('/api/reports/schedule/enable',json={'approved':True}).status_code==422
    assert c.put('/api/reports/settings',json={'account':'someone@example.com'}).status_code==422


def test_schedule_requires_real_preview_and_explicit_approval(tmp_path,monkeypatch):
    s,vault=service(tmp_path);s.test_email()
    registered=[]
    monkeypatch.setattr('app.reports.report_schedule.register',lambda root,at:registered.append(at))
    with pytest.raises(ValueError,match='승인'):s.schedule(True,False)
    with pytest.raises(ValueError,match='미리보기'):s.schedule(True,True)
    assert registered==[]
    run_id,_=s.claim('preview');s.perform(run_id)
    assert s.public()['source_ready']
    s.schedule(True,True)
    assert registered==['09:00']


def test_stale_and_parallel_jobs_do_not_generate_duplicate_delivery(tmp_path):
    s,vault=service(tmp_path);run_id,_=s.claim('preview')
    from app.db import Conflict
    with pytest.raises(Conflict):s.claim('preview')
    with s.db.connect() as con:con.execute("UPDATE report_runs SET updated='2020-01-01T00:00:00+00:00' WHERE id=?",(run_id,))
    again=ReportService(s.db,tmp_path,vault,fake_research())
    assert again.runs()[0]['state']=='unknown'
    new_id,fresh=again.claim('preview');assert fresh and new_id!=run_id


def test_observed_qoo10_public_json_shipping_and_category_are_bound_to_sku():
    ld={'@type':'Product','name':'テストアイパレット','sku':'1097483700','offers':{'price':1500,'priceCurrency':'JPY'},'aggregateRating':{'reviewCount':826}}
    const={'goodscode':'1097483700','gdlc_nm':'ポイントメイク','gd_ship_from_cd':'KR','shipping_from_text':'<a>海外</a> (韓国)','brand_country':'KR','adult_yn':'N','total_sell_amt':4719}
    def html():return '<script type="application/ld+json">'+json.dumps(ld)+'</script><script type="application/json" id="goods-consts-data">'+json.dumps(const)+'</script>'
    row,error=product_facts(html(),'https://www.qoo10.jp/g/1097483700',1)
    assert row and row['category']=='ポイントメイク' and 'gd_ship_from_cd=KR' in row['shipping_evidence']
    assert row['sales'] is None # total_sell_amt is not converted into sales without a verified public label/period.
    const['gd_ship_from_cd']='JP'
    assert product_facts(html(),'https://www.qoo10.jp/g/1097483700',1)[0] is None # Korean brand != Korean dispatch.
    const['gd_ship_from_cd']='KR';const['goodscode']='11111111'
    assert product_facts(html(),'https://www.qoo10.jp/g/1097483700',1)[0] is None
    const['goodscode']='1097483700';const['adult_yn']='Y'
    assert '제외' in product_facts(html(),'https://www.qoo10.jp/g/1097483700',1)[1]
