from pathlib import Path
from datetime import datetime,timedelta,timezone
from email.message import EmailMessage
from html import escape
import json,threading,uuid,os
from pydantic import Field,SecretStr,field_validator
from .models import Base,now
from .db import Conflict,Missing
from .report_mail import CredentialVault,send_message,DeliveryUnknown
from .research import PublicResearch
from . import report_schedule

KST=timezone(timedelta(hours=9))

class ReportSettings(Base):
    account:str=Field(default='',max_length=100)
    at:str=Field(default='09:00',pattern=r'^(?:[01]\d|2[0-3]):[0-5]\d$')
    public_access_approved:bool=False
    @field_validator('account')
    @classmethod
    def email(cls,value):
        import re
        value=value.lower()
        if value and not re.fullmatch(r'[a-z0-9][a-z0-9._-]*@naver\.com',value): raise ValueError('같은 네이버 계정으로 발신·수신하도록 @naver.com 주소를 입력하세요')
        return value

class ReportSettingsUpdate(ReportSettings):
    password:SecretStr|None=None

class Approved(Base): approved:bool=False


def render_report(result,day):
    count=len(result['candidates'])
    subject=f'[SH Auto Seller] {day} 한국 발송 조사 후보 {count}/10개'
    lines=[subject,'공개자료 확인 결과이며 판매·수익을 보장하지 않습니다. 판매량과 인기 목록 노출을 구분합니다.',
           '제외: 성인용품·주류·생물. 원화환산 참고 판매가 9,900~39,900원 / 광고 후 공헌이익률 25%는 추가 검증 대상.']
    for i,row in enumerate(result['candidates'],1):
        sales=f"{row['sales']} / {row['sales_period']}" if row['sales'] is not None and row['sales_period'] else '데이터 없음 (인기 목록 참고이며 판매량 미확인)'
        lines.extend(['',f"{i}. {row['name']}",f"큐텐: {row['qoo10_url']}",f"한국 발송 근거: {row['shipping_evidence']}",
                      f"판매량/기간: {sales}",f"리뷰 수: {row.get('review_count') if row.get('review_count') is not None else '미확인'} (판매량 아님)",f"선정 근거: {row['popularity_evidence']}",f"가격: {row['price_jpy'] if row['price_jpy'] is not None else '미확인'} JPY / {row['price_check']}",
                      f"국내 소싱: {row['sourcing_url'] or '찾지 못함'} / {row['sourcing_status']}",
                      '수익성 추가 검증 필요: 매입가·동일 구성·배송·수수료·세금·광고비 확인',f"확인: {row['collected_at']} / {row['data_status']}"])
    lines+=['','추가 확인 및 수집 상태']+result['warnings']
    lines.append('제외/보류 사유: '+json.dumps(result['skipped'],ensure_ascii=False))
    text='\n'.join(lines)
    # Escaping the entire report keeps supplier/product text from injecting HTML.
    links=''.join('<p><a href="'+escape(row['qoo10_url'],quote=True)+'">'+escape(row['name'])+' · 큐텐 상품</a>'+(' / <a href="'+escape(row['sourcing_url'],quote=True)+'">국내 소싱 참고 (동일 규격 미확인)</a>' if row['sourcing_url'] else '')+'</p>' for row in result['candidates'])
    html='<html lang="ko"><body><h2>SH Auto Seller 일일 조사</h2>'+links+'<pre style="white-space:pre-wrap;font-family:sans-serif;line-height:1.8">'+escape(text)+'</pre></body></html>'
    return subject,text,html

class ReportService:
    def __init__(self,db,root,vault=None,research=None,mailer=None):
        self.db=db;self.root=Path(root);self.vault=vault or CredentialVault(db.path.parent/'private'/'smtp.dpapi')
        self.research=research or PublicResearch();self.mailer=mailer or send_message
        with db.connect() as con:
            con.executescript('''CREATE TABLE IF NOT EXISTS report_settings(id INTEGER PRIMARY KEY CHECK(id=1),body TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS report_runs(id TEXT PRIMARY KEY,kind TEXT NOT NULL,day TEXT NOT NULL,state TEXT NOT NULL,created TEXT NOT NULL,updated TEXT NOT NULL,result TEXT,error TEXT,message_id TEXT);
            CREATE UNIQUE INDEX IF NOT EXISTS report_one_daily ON report_runs(day) WHERE kind='daily';''')
        with db.connect() as con:
            cutoff=(datetime.now(timezone.utc)-timedelta(minutes=25)).isoformat()
            con.execute("UPDATE report_runs SET state='unknown',error='중단된 작업입니다. 보낸메일함을 확인하세요. 자동 재전송하지 않습니다.' WHERE state IN ('queued','running','sending') AND updated<?",(cutoff,))
    def config(self):
        with self.db.connect() as con:r=con.execute('SELECT body FROM report_settings WHERE id=1').fetchone()
        return json.loads(r[0]) if r else dict(**ReportSettings().model_dump(),enabled=False,mail_tested_at=None)
    def _save(self,data):
        with self.db.connect() as con: con.execute('INSERT OR REPLACE INTO report_settings VALUES(1,?)',(json.dumps(data,ensure_ascii=False),))
    def source_ready(self):
        cutoff=(datetime.now(timezone.utc)-timedelta(days=7)).isoformat()
        return any(r['kind']=='preview' and r['state']=='ready' and r['created']>=cutoff and r['result'] and r['result']['candidates'] for r in self.runs())
    def public(self):
        cfg=self.config()
        return dict(**cfg,source_ready=self.source_ready(),password_set=self.vault.has(),windows=os.name=='nt',task_registered=report_schedule.exists(self.root),timezone='Asia/Seoul',desired_count=10,
                    source_status='공개 HTML 어댑터 · 2026-10-21 실제 페이지에서 한국 발송 후보 추출 확인. 접근/구조 확인 실패 시 미수집으로 보고',smtp_host='smtp.naver.com',smtp_port=465)
    def save(self,body):
        cfg=self.config()
        with self.db.connect() as con:
            active=con.execute("SELECT 1 FROM report_runs WHERE state IN ('running','sending') LIMIT 1").fetchone()
        if active: raise Conflict('조사/발송 중에는 설정을 변경할 수 없습니다. 작업 상태를 먼저 확인하세요.')
        changed=any(cfg.get(k)!=v for k,v in body.model_dump(exclude={'password'}).items())
        if cfg.get('enabled') and changed: raise Conflict('기존 예약을 먼저 해제한 뒤 계정·조사 설정을 변경하세요.')
        password=body.password.get_secret_value() if body.password is not None else ''
        if cfg.get('enabled') and password: raise Conflict('인증정보 변경 전 예약을 해제하세요.')
        if password:
            if not 1<=len(password)<=500: raise ValueError('유효한 메일 인증정보를 입력하세요.')
            self.vault.put(password)
        if cfg.get('account')!=body.account and not password: self.vault.clear()
        if cfg.get('account')!=body.account or password: cfg['mail_tested_at']=None
        cfg.update(body.model_dump(exclude={'password'}));self._save(cfg);return self.public()
    def test_email(self):
        cfg=self.config()
        if not cfg['account']: raise ValueError('발신·수신 네이버 계정을 먼저 저장하세요.')
        msg=EmailMessage();msg['Subject']='[SH Auto Seller] 메일 연결 테스트';msg.set_content('발신·수신 계정 연결 테스트입니다. 이 메일은 일일 조사나 예약 등록 완료를 의미하지 않습니다.')
        self.mailer(cfg['account'],self.vault.get(),msg)
        cfg['mail_tested_at']=now();self._save(cfg);return {'sent':True,'message':'테스트 메일을 전송했습니다. 보낸메일함·받은메일함을 확인하세요.'}
    def schedule(self,enabled,approved):
        if not approved: raise ValueError('메일 예약 변경에 대한 승인이 필요합니다.')
        cfg=self.config()
        if enabled:
            if not cfg['account'] or not self.vault.has() or not cfg.get('mail_tested_at'): raise ValueError('계정 저장과 테스트 메일 발송을 먼저 완료하세요.')
            if not cfg['public_access_approved']: raise ValueError('공개자료 자동 조회 허용 범위를 먼저 확인하세요.')
            if not self.source_ready(): raise ValueError('먼저 공개자료 조사 미리보기에서 한국 발송·분류가 확인된 실제 후보를 1개 이상 확보하세요. 미수집 상태로 예약을 활성화하지 않습니다.')
            report_schedule.register(self.root,cfg['at'])
        else:
            if os.name!='nt': raise ValueError('원래 예약을 등록한 Windows PC에서 예약을 해제하세요.')
            if report_schedule.exists(self.root): report_schedule.remove(self.root)
        cfg['enabled']=enabled;self._save(cfg);return self.public()
    def runs(self):
        with self.db.connect() as con:
            rows=[dict(r) for r in con.execute('SELECT * FROM report_runs ORDER BY created DESC,rowid DESC LIMIT 20')]
        for r in rows:r['result']=json.loads(r['result']) if r['result'] else None
        return rows
    def claim(self,kind,day=None):
        day=day or datetime.now(KST).date().isoformat()
        with self.db.connect() as con:
            con.execute('BEGIN IMMEDIATE')
            if kind=='daily':
                old=con.execute("SELECT * FROM report_runs WHERE kind='daily' AND day=?",(day,)).fetchone()
                if old: return old['id'],False
            if con.execute("SELECT 1 FROM report_runs WHERE state IN ('queued','running','sending') LIMIT 1").fetchone(): raise Conflict('진행 중인 조사/발송이 있습니다. 완료 후 새 작업을 시작하세요.')
            run_id=uuid.uuid4().hex
            con.execute('INSERT INTO report_runs VALUES(?,?,?,?,?,?,NULL,NULL,?)',(run_id,kind,day,'queued',now(),now(),f'<sh-report-{run_id}@sh-auto-seller.local>'))
        return run_id,True
    def _update(self,run_id,state,result=None,error=None):
        with self.db.connect() as con:
            con.execute('UPDATE report_runs SET state=?,updated=?,result=COALESCE(?,result),error=? WHERE id=?',(state,now(),json.dumps(result,ensure_ascii=False) if result is not None else None,error,run_id))
    def perform(self,run_id,send=False):
        with self.db.connect() as con:
            con.execute('BEGIN IMMEDIATE')
            row=con.execute('SELECT * FROM report_runs WHERE id=?',(run_id,)).fetchone()
            if not row: raise Missing('조사 기록이 없습니다.')
            # A restart must not re-enter an uncertain sending state.
            if row['state']!='queued': return
            con.execute('UPDATE report_runs SET state=?,updated=? WHERE id=?',('running',now(),run_id))
        cfg=self.config()
        try:
            if send and (not cfg.get('mail_tested_at') or not cfg.get('account') or not self.vault.has()): raise ValueError('메일 연결 테스트를 먼저 완료하세요.')
            result=self.research.collect(cfg['public_access_approved'],self.db.settings().exchange_krw_per_100_jpy,self.db.list())
            self._update(run_id,'ready',result)
            if not send:return
            subject,text,html=render_report(result,row['day']);msg=EmailMessage();msg['Subject']=subject;msg['Message-ID']=row['message_id'];msg.set_content(text);msg.add_alternative(html,subtype='html')
            self._update(run_id,'sending')
            self.mailer(cfg['account'],self.vault.get(),msg)
            self._update(run_id,'sent')
        except DeliveryUnknown as exc:self._update(run_id,'unknown',error=str(exc))
        except ValueError as exc:self._update(run_id,'failed',error=str(exc))
        except Exception:self._update(run_id,'failed',error='조사/발송 중 오류가 발생했습니다. 인증정보는 로그에 기록하지 않았습니다. 접근·자료 구조·프로그램 상태를 확인하세요.')
    def start(self,send=False):
        cfg=self.config()
        if send and not cfg.get('mail_tested_at'): raise ValueError('테스트 메일을 먼저 발송하세요.')
        run_id,fresh=self.claim('daily' if send else 'preview')
        if fresh:threading.Thread(target=self.perform,args=(run_id,send),daemon=True).start()
        return {'run_id':run_id,'new':fresh,'message':'조사를 시작했습니다.' if fresh else '오늘 발송 작업이 이미 있습니다. 중복 발송하지 않았습니다.'}
