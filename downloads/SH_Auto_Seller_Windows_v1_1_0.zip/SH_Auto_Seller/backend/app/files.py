from io import BytesIO, StringIO
import csv
import json
import uuid
import zipfile
from openpyxl import load_workbook, Workbook
from pydantic import ValidationError
from .models import Product, FIELDS, ALIASES, dedup_key, now
from .db import Conflict, Missing

MAX_FILE=10*1024*1024
MAX_ROWS=5000

def json_cell(value):
    if value is None: return ''
    if hasattr(value,'isoformat'): return value.isoformat()
    return str(value)

def parse_file(filename,content):
    if len(content)>MAX_FILE: raise ValueError('최대 10MB 파일만 지원합니다')
    raw={}
    if filename.lower().endswith('.csv'):
        try: text=content.decode('utf-8-sig')
        except UnicodeDecodeError:
            try: text=content.decode('cp949')
            except UnicodeDecodeError as e: raise ValueError('CSV 인코딩은 UTF-8 또는 CP949를 사용하세요') from e
        raw['CSV']=list(csv.reader(StringIO(text)))
    elif filename.lower().endswith('.xlsx'):
        try:
            with zipfile.ZipFile(BytesIO(content)) as z:
                if sum(i.file_size for i in z.infolist())>50*1024*1024: raise ValueError('XLSX 압축 해제 크기는 50MB 이하만 지원합니다')
            wb=load_workbook(BytesIO(content),read_only=True,data_only=False)
            if len(wb.sheetnames)>20: raise ValueError('시트는 최대 20개')
            try:
                for sheet in wb:
                    rows=[]
                    if sheet.max_column and sheet.max_column>100: raise ValueError('열은 최대 100개')
                    for i,row in enumerate(sheet.iter_rows(values_only=True)):
                        if i>MAX_ROWS: raise ValueError('시트당 데이터는 최대 5,000행')
                        rows.append(list(row))
                    raw[sheet.title]=rows
            finally: wb.close()
        except (zipfile.BadZipFile,KeyError,TypeError) as e: raise ValueError('올바른 XLSX 파일이 아닙니다') from e
    else: raise ValueError('CSV 또는 XLSX 파일을 선택하세요')
    result={}; total_cells=0
    for title,rows in raw.items():
        if not rows: continue
        if len(rows)>MAX_ROWS+1: raise ValueError('시트당 데이터는 최대 5,000행')
        headers=[json_cell(x).strip() for x in rows[0]]
        while headers and not headers[-1]: headers.pop()
        if not headers or len(headers)>100 or any(not x for x in headers) or len(set(headers))!=len(headers):
            raise ValueError(f'{title}: 첫 행의 열 이름은 빈칸 없이 고유해야 합니다 (최대 100개)')
        data=[]
        for index,row in enumerate(rows[1:],2):
            if any(json_cell(v).strip() for v in row[len(headers):]): raise ValueError(f'{title} {index}행: 열 이름이 없는 추가 데이터가 있습니다')
            values=[json_cell(v) for v in row[:len(headers)]]
            if not any(v.strip() for v in values): continue
            values+=['']*(len(headers)-len(values))
            if any(len(v)>40000 for v in values): raise ValueError('셀 한 개는 40,000자 이하')
            data.append({'row':index,'values':dict(zip(headers,values))})
        total_cells+=len(data)*len(headers)
        if total_cells>200000: raise ValueError('전체 파일은 200,000셀 이하')
        mapping={field:next((h for h in headers if h.lower().strip() in [a.lower() for a in aliases]),'') for field,aliases in ALIASES.items()}
        result[title]={'headers':headers,'rows':data,'suggested_mapping':mapping}
    if not result: raise ValueError('비어 있는 파일입니다')
    return result


def cell_value(field,value):
    text=value.strip()
    if not text: return None if field in {'purchase_krw','domestic_shipping_krw','stock','weight_kg'} else ([] if field=='image_urls' else False if field=='image_rights_confirmed' else '')
    if text.startswith('='): raise ValueError('수식은 허용하지 않습니다. Excel에서 값으로 붙여 넣은 파일을 사용하세요')
    if field in {'purchase_krw','domestic_shipping_krw','stock','weight_kg'}:
        try:
            num=float(text.replace(',',''))
            if field=='stock':
                if not num.is_integer(): raise ValueError('재고는 정수여야 합니다')
                return int(num)
            return num
        except (ValueError,OverflowError) as e: raise ValueError('유효한 숫자가 필요합니다') from e
    if field=='image_rights_confirmed':
        if text.lower() not in {'true','false','1','0','예','아니오'}: raise ValueError('이미지 사용권은 예/아니오 또는 true/false')
        return text.lower() in {'true','1','예'}
    if field=='image_urls': return [x.strip() for x in text.replace(';','\n').splitlines() if x.strip()]
    return text


def preview(db,request):
    with db.connect() as con:
        upload=con.execute('SELECT * FROM uploads WHERE id=?',(request.upload_id,)).fetchone()
    if not upload: raise Missing('업로드 자료가 없습니다. 다시 업로드하세요')
    sheets=json.loads(upload['body'])
    if request.sheet not in sheets: raise ValueError('존재하지 않는 시트')
    sheet=sheets[request.sheet]
    mapping={k:v for k,v in request.mapping.items() if v}
    if set(mapping)-set(FIELDS): raise ValueError('알 수 없는 매핑 항목')
    if len(set(mapping.values()))!=len(mapping): raise ValueError('같은 원본 열을 여러 항목에 매핑할 수 없습니다')
    if set(mapping.values())-set(sheet['headers']): raise ValueError('존재하지 않는 원본 열')
    if 'name' not in mapping: raise ValueError('상품명 열을 매핑하세요')
    existing=db.list(); bysku={p['sku']:p for p in existing}
    bykey={dedup_key(Product(**{k:p[k] for k in FIELDS})):p for p in existing if p['source_url']}
    results=[]; seen_sku=set(); seen_key=set(); seen_id=set()
    for entry in sheet['rows']:
        result={'row':entry['row'],'action':'오류','errors':[],'product':None,'existing_id':None,'version':None}
        try:
            values={f:cell_value(f,entry['values'][h]) for f,h in mapping.items()}
            if not values.get('collected_at'): values['collected_at']=now()
            values.setdefault('data_status','공급처 파일'); values.setdefault('collection_method','파일 가져오기')
            initial=Product(**values)
            key=dedup_key(initial)
            old_sku=bysku.get(initial.sku); old_key=bykey.get(key) if key else None
            if old_sku and old_key and old_sku['id']!=old_key['id']: raise ValueError('SKU와 URL+옵션이 서로 다른 기존 상품을 가리킵니다')
            old=old_sku or old_key
            if old and not request.merge: raise ValueError('기존 상품과 중복. 병합을 선택하거나 원본을 확인하세요')
            if old:
                if initial.sku and initial.sku!=old['sku']: raise ValueError('같은 URL+옵션의 SKU가 다릅니다. 기존 SKU를 사용하세요')
                base={k:old[k] for k in FIELDS}; base.update(values); base['sku']=old['sku']
                product=Product(**base); result.update(action='병합',existing_id=old['id'],version=old['version'])
            else:
                product=initial
                if not product.sku: product.sku='SH-'+uuid.uuid4().hex[:12].upper()
                result['action']='신규'
            key=dedup_key(product)
            if product.sku in seen_sku or (key and key in seen_key) or (old and old['id'] in seen_id): raise ValueError('업로드 파일 안에 중복 SKU 또는 URL+옵션이 있습니다')
            seen_sku.add(product.sku)
            if key: seen_key.add(key)
            if old: seen_id.add(old['id'])
            result['product']=product.model_dump()
        except ValidationError as e:
            result['action']='오류'; result['errors']=[f"{'.'.join(str(x) for x in err['loc'])}: {err['msg']}" for err in e.errors()]
        except (ValueError,TypeError) as e: result['action']='오류'; result['errors']=[str(e)]
        results.append(result)
    batch_id=uuid.uuid4().hex
    with db.connect() as con: con.execute('INSERT INTO batches VALUES(?,?,?,NULL,?)',(batch_id,json.dumps(results,ensure_ascii=False),'preview',now()))
    return dict(batch_id=batch_id,rows=results,valid=sum(r['action']!='오류' for r in results),errors=sum(r['action']=='오류' for r in results))


def commit(db,batch_id):
    with db.connect() as con:
        con.execute('BEGIN IMMEDIATE')
        batch=con.execute('SELECT * FROM batches WHERE id=?',(batch_id,)).fetchone()
        if not batch: raise Missing('가져오기 검증 결과를 찾을 수 없습니다')
        if batch['state']=='committed': return json.loads(batch['result'])
        rows=json.loads(batch['body']); inserted=updated=skipped=0
        for r in rows:
            if r['action']=='오류': skipped+=1; continue
            db.write(con,Product(**r['product']),r['existing_id'],r['version'])
            if r['existing_id']: updated+=1
            else: inserted+=1
        result=dict(inserted=inserted,updated=updated,skipped=skipped,batch_id=batch_id)
        con.execute('UPDATE batches SET state=?,result=? WHERE id=?',('committed',json.dumps(result),batch_id))
        return result


def safe(value):
    if isinstance(value,(dict,list)): value=json.dumps(value,ensure_ascii=False)
    if isinstance(value,str) and value.lstrip().startswith(('=','+','-','@')): return "'"+value
    return value


def tabular(headers,rows,fmt):
    if fmt=='csv':
        buf=StringIO(); writer=csv.writer(buf); writer.writerow(headers)
        writer.writerows([[safe(v) for v in row] for row in rows]); return buf.getvalue().encode('utf-8-sig')
    wb=Workbook(); ws=wb.active; ws.title='상품자료'; ws.append(headers)
    for row in rows: ws.append([safe(v) for v in row])
    ws.freeze_panes='A2'; ws.auto_filter.ref=ws.dimensions
    out=BytesIO(); wb.save(out); return out.getvalue()


def product_export(products,fmt):
    keys=list(FIELDS)
    rows=[]
    for p in products:
        vals=[]
        for k in keys:
            value=p[k]
            if k=='image_urls': value='\n'.join(value)
            vals.append(value)
        vals += [p['workflow_status'],p['updated_at']]
        rows.append(vals)
    return tabular([FIELDS[k] for k in keys]+['진행상태','최근수정'],rows,fmt)
