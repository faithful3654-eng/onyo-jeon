"""TLS SMTP and Windows user-scoped DPAPI storage. Secrets never enter SQLite."""
from pathlib import Path
from email.message import EmailMessage
import ctypes
from ctypes import wintypes
import os,smtplib,ssl

class CredentialVault:
    def __init__(self,path): self.path=Path(path)
    def get(self):
        # Optional development-only binding is server-side, never returned by the API.
        if os.name!='nt': return os.environ.get('SH_REPORT_SMTP_PASSWORD','')
        if not self.path.exists(): return ''
        return self._crypt(self.path.read_bytes(),False).decode('utf-8')
    def clear(self):
        if self.path.exists(): self.path.unlink()
    def has(self):
        try: return bool(self.get())
        except (ValueError,OSError): return False
    def put(self,secret):
        if os.name!='nt': raise ValueError('비밀정보 화면 저장은 Windows PC에서 사용하세요. 이 클라우드에는 계정 비밀번호를 저장하지 않습니다.')
        encrypted=self._crypt(secret.encode('utf-8'),True)
        self.path.parent.mkdir(parents=True,exist_ok=True)
        tmp=self.path.with_suffix('.tmp');tmp.write_bytes(encrypted);tmp.replace(self.path)
    @staticmethod
    def _crypt(raw,encrypt):
        class Blob(ctypes.Structure): _fields_=[('size',wintypes.DWORD),('data',ctypes.POINTER(ctypes.c_ubyte))]
        buffer=ctypes.create_string_buffer(raw);source=Blob(len(raw),ctypes.cast(buffer,ctypes.POINTER(ctypes.c_ubyte)));output=Blob()
        crypt32=ctypes.WinDLL('crypt32',use_last_error=True);kernel32=ctypes.WinDLL('kernel32',use_last_error=True)
        signature=[ctypes.POINTER(Blob),wintypes.LPCWSTR,ctypes.POINTER(Blob),ctypes.c_void_p,ctypes.c_void_p,wintypes.DWORD,ctypes.POINTER(Blob)]
        if encrypt:
            func=crypt32.CryptProtectData;func.argtypes=signature
            ok=func(ctypes.byref(source),'SH Auto Seller SMTP',None,None,None,1,ctypes.byref(output))
        else:
            func=crypt32.CryptUnprotectData;signature[1]=ctypes.c_void_p;func.argtypes=signature
            ok=func(ctypes.byref(source),None,None,None,None,1,ctypes.byref(output))
        if not ok: raise ValueError('Windows 비밀정보를 처리하지 못했습니다. 동일한 Windows 계정에서 메일 인증정보를 다시 저장하세요.')
        kernel32.LocalFree.argtypes=[ctypes.c_void_p];kernel32.LocalFree.restype=ctypes.c_void_p
        try: return ctypes.string_at(output.data,output.size)
        finally: kernel32.LocalFree(ctypes.cast(output.data,ctypes.c_void_p))

class DeliveryUnknown(ValueError): pass

def send_message(account,password,message,smtp_factory=smtplib.SMTP_SSL):
    if not password: raise ValueError('발신 인증정보가 아직 연결되지 않았습니다.')
    # Both recipient and sender are deliberately the same explicitly selected account.
    message['From']=account;message['To']=account
    transmitting=False
    try:
        with smtp_factory('smtp.naver.com',465,timeout=30,context=ssl.create_default_context()) as smtp:
            smtp.login(account,password)
            transmitting=True
            refused=smtp.send_message(message)
            if refused: raise ValueError('메일 서버가 수신 주소를 거절했습니다.')
    except smtplib.SMTPAuthenticationError: raise ValueError('네이버 메일 인증 실패. 계정의 외부 메일/SMTP 설정과 허용된 인증정보를 확인하세요.') from None
    except (smtplib.SMTPException,OSError,TimeoutError):
        if transmitting: raise DeliveryUnknown('전송 결과가 불명확합니다. 중복 방지를 위해 자동 재전송하지 않습니다. 보낸메일함에서 Message-ID를 확인하세요.') from None
        raise ValueError('메일 서버에 연결할 수 없습니다. 인터넷·SMTP 사용 설정을 확인하세요.') from None
