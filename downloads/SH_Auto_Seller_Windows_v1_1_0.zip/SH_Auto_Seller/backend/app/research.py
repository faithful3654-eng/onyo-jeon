"""Read-only public ranking research. No authentication or block bypass.
The public HTML adapter is conservative: missing structured facts remain unknown.
"""
from html.parser import HTMLParser
from urllib.parse import urljoin,urlsplit
from urllib.request import Request,build_opener,HTTPRedirectHandler
from urllib.error import URLError,HTTPError
from urllib.robotparser import RobotFileParser
from datetime import datetime,timezone
import json,re,time,unicodedata

ORIGIN='https://www.qoo10.jp'
RANKING=ORIGIN+'/gmkt.inc/Bestsellers/'
AGENT='SHAutoSellerResearch'
EXCLUDED=re.compile(r'アダルト|成人用品|成人向け|性具|大人のおもちゃ|ラブグッズ|コンドーム|セクストイ|日本酒|焼酎|ワイン|ビール|ウイスキー|リキュール|ウォッカ|アルコール飲料|生体|活魚|活貝|活海老|生きた|苗木|生花|観葉植物|生鮮|성인용품|주류|활어')
RELATED=re.compile(r'手袋|グローブ|キッチン|生活用品|保護|장갑|주방|보호')

class Unavailable(ValueError): pass

class SameSiteRedirect(HTTPRedirectHandler):
    def __init__(self,allowed): self.allowed=allowed
    def redirect_request(self,req,fp,code,msg,headers,newurl):
        safe_url(newurl)
        if not self.allowed(newurl): raise Unavailable('robots.txt 제한 주소로의 이동을 중단했습니다.')
        return super().redirect_request(req,fp,code,msg,headers,newurl)

def safe_url(url):
    p=urlsplit(url)
    if p.scheme!='https' or p.hostname!='www.qoo10.jp' or p.username or p.password:
        raise Unavailable('허용된 큐텐 공개 HTTPS 주소만 조회합니다.')
    if re.search(r'login|captcha|sign.?in',p.path,re.I): raise Unavailable('로그인·인증이 필요한 주소는 조회하지 않습니다.')
    return url

class Facts(HTMLParser):
    def __init__(self):
        super().__init__();self.links=[];self.jsonld=[];self.pairs={};self.cell=None;self.cell_text=[];self.key=None;self.script=False;self.script_text=[];self.ignore=0;self.script_kind=None;self.consts={}
    def handle_starttag(self,tag,attrs):
        attrs=dict(attrs)
        if tag=='a' and attrs.get('href'): self.links.append(attrs['href'])
        if tag=='script':
            kind=attrs.get('type','').lower()
            self.script_kind='ld' if kind=='application/ld+json' else 'consts' if kind=='application/json' and attrs.get('id')=='goods-consts-data' else None
            self.script=bool(self.script_kind);self.script_text=[]
        if tag in {'td','th','dt','dd'}:
            self.cell=tag;self.cell_text=[]
    def handle_data(self,data):
        if self.script: self.script_text.append(data)
        if self.cell: self.cell_text.append(data)
    def handle_endtag(self,tag):
        if tag=='script' and self.script:
            try:
                data=json.loads(''.join(self.script_text))
                if self.script_kind=='ld':self.jsonld.append(data)
                elif isinstance(data,dict):self.consts=data
            except (ValueError,TypeError): pass
            self.script=False
        if tag==self.cell:
            text=re.sub(r'\s+',' ',''.join(self.cell_text)).strip()
            if self.key:
                self.pairs[self.key]=text;self.key=None
            elif re.fullmatch(r'(発送国|発送元|出荷国|出荷元|配送元|販売数|累計販売数|販売個数|累計販売個数|販売期間|カテゴリ|カテゴリー)',text): self.key=text
            self.cell=None;self.cell_text=[]

def products_json(value):
    if isinstance(value,list):
        for v in value: yield from products_json(v)
    elif isinstance(value,dict):
        if value.get('@type')=='Product' or (isinstance(value.get('@type'),list) and 'Product' in value['@type']): yield value
        for key in ['@graph','mainEntity','itemListElement','item']:
            if key in value: yield from products_json(value[key])

def ranking_links(html):
    parsed=Facts();parsed.feed(html);result=[];seen=set()
    for href in parsed.links:
        url=urljoin(RANKING,href);p=urlsplit(url)
        if p.hostname!='www.qoo10.jp' or p.scheme!='https': continue
        match=re.search(r'(?:/g/|/item/(?:[^/]+/)*)(\d{7,12})(?:[/?#]|$)',p.path+'/')
        if not match: continue
        item=match.group(1)
        if item in seen: continue
        seen.add(item);result.append(url.split('#')[0])
    return result

def product_facts(html,url,position):
    parsed=Facts();parsed.feed(html)
    products=[v for j in parsed.jsonld for v in products_json(j)]
    # Conflicting/multiple product objects cannot safely identify the main item.
    if len(products)!=1: return None,'상품 구조화 정보 미확인 또는 여러 상품 혼재'
    product=products[0];name=product.get('name')
    if not isinstance(name,str) or not name.strip(): return None,'상품명 미확인'
    constants=parsed.consts if str(parsed.consts.get('goodscode',''))==str(product.get('sku','')) and product.get('sku') else {}
    if constants.get('adult_yn')=='Y':return None,'제외 카테고리 (성인 제한 표기)'
    category=product.get('category') or parsed.pairs.get('カテゴリ') or parsed.pairs.get('カテゴリー') or constants.get('gdlc_nm')
    if not isinstance(category,str) or not category.strip(): return None,'제외 카테고리 판정을 위한 분류 자료 부족'
    if EXCLUDED.search(name+' '+category): return None,'제외분야 키워드 감지 · 검토 보류'
    origin=next((parsed.pairs[k] for k in ['発送国','発送元','出荷国','出荷元','配送元'] if k in parsed.pairs),None)
    if not origin and constants.get('gd_ship_from_cd')=='KR':
        text=re.sub(r'<[^>]*>','',str(constants.get('shipping_from_text',''))).strip()
        if re.fullmatch(r'海外\s*\(韓国\)',text):origin='海外 (韓国) · 공개 상품 데이터 gd_ship_from_cd=KR'
    embedded_origin=origin=='海外 (韓国) · 공개 상품 데이터 gd_ship_from_cd=KR'
    if not origin or (not embedded_origin and not re.fullmatch(r'(韓国|大韓民国|South Korea|Korea|KR)(?:\s*\([^)]*\))?',origin,re.I)): return None,'한국 발송 표기 미확인'
    offers=product.get('offers',{})
    if isinstance(offers,list): offers=offers[0] if len(offers)==1 else {}
    if not isinstance(offers,dict): offers={}
    price=None
    if offers.get('priceCurrency')=='JPY':
        try:
            value=float(str(offers.get('price','')).replace(',',''))
            if 0<value<1e10: price=value
        except (TypeError,ValueError): pass
    sales=None;sales_period=None;sales_evidence=None
    for label in ['累計販売数','累計販売個数','販売数','販売個数']:
        if label not in parsed.pairs: continue
        text=parsed.pairs[label];m=re.fullmatch(r'([\d,]+)\s*(?:個|件|点|本|セット)?',text)
        if m:
            sales=int(m.group(1).replace(',',''));sales_evidence=label+': '+text
            sales_period=parsed.pairs.get('販売期間') or ('累計（開始日不明）' if label.startswith('累計') else None)
            break
    rating=product.get('aggregateRating') or {}
    reviews=rating.get('reviewCount') if isinstance(rating,dict) else None
    return dict(name=name[:300],category=category[:200],qoo10_url=url,shipping_origin='한국',shipping_evidence=origin,
                sales=sales,sales_period=sales_period,sales_evidence=sales_evidence,
                popularity_evidence=f'공식 베스트셀러 페이지에서 발견한 {position}번째 상품 링크 (공식 숫자 순위 미확인)',
                discovery_order=position,review_count=reviews,price_jpy=price,
                related=bool(RELATED.search(name+' '+category)),data_status='공개 페이지 확인',
                collected_at=datetime.now(timezone.utc).isoformat(),profit_status='수익성 추가 검증 필요',
                sourcing_url=None,sourcing_status='한국 소싱처 미확인'),None

class PublicResearch:
    def __init__(self,fetcher=None,pause=time.sleep):
        self.fetcher=fetcher;self.pause=pause
        self.robots=None
        self.opener=build_opener(SameSiteRedirect(lambda url:self.robots.can_fetch(AGENT,url) if self.robots else urlsplit(url).path=='/robots.txt'))
    def fetch(self,url):
        safe_url(url)
        if self.fetcher: return self.fetcher(url)
        try:
            with self.opener.open(Request(url,headers={'User-Agent':AGENT+'/1.0 (read-only local seller research)'}),timeout=20) as r:
                raw=r.read(2_000_001)
                if len(raw)>2_000_000: raise Unavailable('페이지 크기가 지원 범위를 넘었습니다.')
                html=raw.decode(r.headers.get_content_charset() or 'utf-8',errors='replace')
                if re.search(r'captcha|access denied|アクセスが制限|不正なアクセス',html,re.I): raise Unavailable('접근 제한 또는 CAPTCHA가 표시되어 조사를 중단했습니다.')
                return html
        except Unavailable: raise
        except (HTTPError,URLError,TimeoutError,OSError): raise Unavailable('큐텐 공개 자료에 접근할 수 없습니다. 네트워크 정책·사이트 응답을 확인하세요. 차단을 우회하지 않습니다.') from None
    def collect(self,approved,exchange=None,catalog=None):
        result=dict(candidates=[],warnings=[],skipped={},checked=0,requested=10,source=RANKING,verified_sales_count=0)
        if not approved:
            result['warnings']=['공개자료 자동 조회 허용 범위 확인이 필요합니다.'];return result
        try:
            robots=RobotFileParser();robots.parse(self.fetch(ORIGIN+'/robots.txt').splitlines())
            if not robots.can_fetch(AGENT,RANKING): raise Unavailable('robots.txt에서 해당 자동 조회를 허용하지 않습니다.')
            self.robots=robots
            delay=max(2,robots.crawl_delay(AGENT) or 0)
            if delay>20: raise Unavailable('서버가 긴 조회 간격을 요구해 자동 조사를 보류했습니다. 제한을 우회하지 않습니다.')
            self.pause(delay)
            links=ranking_links(self.fetch(RANKING))
            if not links: raise Unavailable('공개 순위 페이지에서 상품 링크를 확인하지 못했습니다. 페이지 구조 변경 또는 접근 범위 확인이 필요합니다.')
            for position,url in enumerate(links[:30],1):
                if not robots.can_fetch(AGENT,url): result['skipped']['robots 제한']=result['skipped'].get('robots 제한',0)+1;continue
                self.pause(delay)
                try:
                    row,reason=product_facts(self.fetch(url),url,position);result['checked']+=1
                    if not row:
                        result['skipped'][reason]=result['skipped'].get(reason,0)+1;continue
                    row['price_krw_equivalent']=round(row['price_jpy']*exchange/100,2) if row['price_jpy'] is not None and exchange else None
                    if row['price_krw_equivalent'] is not None and not 9900<=row['price_krw_equivalent']<=39900:
                        result['skipped']['원화환산 목표 판매가 범위 밖']=result['skipped'].get('원화환산 목표 판매가 범위 밖',0)+1;continue
                    row['price_check']='조건 범위' if row['price_krw_equivalent'] is not None else '판매가/환율 추가 확인 필요'
                    normalize=lambda text:re.sub(r'\s+','',unicodedata.normalize('NFKC',str(text))).casefold()
                    matches=[p for p in (catalog or []) if p.get('data_status') not in {'데모','추정','미수집'} and p.get('source_url') and normalize(p.get('name'))==normalize(row['name'])]
                    if len(matches)==1:
                        row['sourcing_url']=matches[0]['source_url'];row['sourcing_status']='사용자 상품마스터의 동일 이름 후보 (동일 규격·공급 조건 미확인)'
                    result['candidates'].append(row)
                except Unavailable as exc:
                    result['warnings'].append(str(exc));break
            # Evidence and discovery order drive selection; reviews never stand in for sales.
            result['candidates'].sort(key=lambda r:(not bool(r['sales'] is not None and r['sales_period']),not r['related'],r['discovery_order']))
            result['candidates']=result['candidates'][:10]
            result['verified_sales_count']=sum(r['sales'] is not None and bool(r['sales_period']) for r in result['candidates'])
        except Unavailable as exc: result['warnings'].append(str(exc))
        if len(result['candidates'])<10: result['warnings'].append(f"조건 확인 후보 {len(result['candidates'])}/10개. 미확인 상품으로 채우지 않았습니다.")
        result['warnings'].append('공식 인기 목록에서 최대 30개 상품 링크를 표본 조사했습니다. 전체 시장 전수조사나 공식 숫자 순위를 의미하지 않습니다.')
        result['warnings'].append('공식 인기 목록 발견은 판매량 증명이 아닙니다. 판매량·기간 미공개는 미확인, 원가·광고비 부족은 수익성 추가 검증 필요입니다.')
        return result
