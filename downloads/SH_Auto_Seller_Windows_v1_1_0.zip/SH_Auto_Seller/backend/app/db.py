from contextlib import contextmanager
from pathlib import Path
import json
import sqlite3
import uuid
from .models import Product, Settings, dedup_key, now

class Conflict(ValueError): pass
class Missing(ValueError): pass

class Database:
    def __init__(self,path):
        self.path=Path(path); self.path.parent.mkdir(parents=True,exist_ok=True)
        with self.connect() as con:
            con.executescript('''
            CREATE TABLE IF NOT EXISTS products(id TEXT PRIMARY KEY, sku TEXT UNIQUE NOT NULL, dedup TEXT UNIQUE, body TEXT NOT NULL, version INTEGER NOT NULL, updated TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS settings(id INTEGER PRIMARY KEY CHECK(id=1),body TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS uploads(id TEXT PRIMARY KEY,body TEXT NOT NULL,created TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS batches(id TEXT PRIMARY KEY,body TEXT NOT NULL,state TEXT NOT NULL,result TEXT,created TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY,action TEXT NOT NULL,sku TEXT,created TEXT NOT NULL);
            ''')
    @contextmanager
    def connect(self):
        con=sqlite3.connect(self.path,timeout=15); con.row_factory=sqlite3.Row
        try:
            with con: yield con
        finally: con.close()
    def unpack(self,r):
        if not r: raise Missing('상품을 찾을 수 없습니다')
        return dict(id=r['id'],version=r['version'],updated_at=r['updated'],workflow_status='수집 완료',**json.loads(r['body']))
    def list(self):
        with self.connect() as con: return [self.unpack(r) for r in con.execute('SELECT * FROM products ORDER BY updated DESC,id')]
    def get(self,pid):
        with self.connect() as con: return self.unpack(con.execute('SELECT * FROM products WHERE id=?',(pid,)).fetchone())
    def write(self,con,product,pid=None,expected_version=None):
        product=product.model_copy(deep=True)
        if not product.sku: product.sku='SH-'+uuid.uuid4().hex[:12].upper()
        if pid:
            old=con.execute('SELECT * FROM products WHERE id=?',(pid,)).fetchone()
            if not old: raise Missing('상품을 찾을 수 없습니다')
            if old['version']!=expected_version: raise Conflict('다른 화면에서 변경되었습니다. 새로 조회 후 다시 저장하세요')
        else: old=None; pid=uuid.uuid4().hex
        body=json.dumps(product.model_dump(),ensure_ascii=False,allow_nan=False); updated=now()
        try:
            if old: con.execute('UPDATE products SET sku=?,dedup=?,body=?,version=version+1,updated=? WHERE id=?',(product.sku,dedup_key(product),body,updated,pid))
            else: con.execute('INSERT INTO products VALUES(?,?,?,?,1,?)',(pid,product.sku,dedup_key(product),body,updated))
        except sqlite3.IntegrityError as e: raise Conflict('동일 SKU 또는 원본 URL+옵션의 상품이 이미 있습니다') from e
        con.execute('INSERT INTO audit(action,sku,created) VALUES(?,?,?)',('상품 수정' if old else '상품 추가',product.sku,updated))
        return pid
    def create(self,p):
        with self.connect() as con: pid=self.write(con,p)
        return self.get(pid)
    def update(self,pid,p,version):
        with self.connect() as con: self.write(con,p,pid,version)
        return self.get(pid)
    def delete(self,pid,version):
        with self.connect() as con:
            r=con.execute('SELECT * FROM products WHERE id=?',(pid,)).fetchone()
            if not r: raise Missing('상품을 찾을 수 없습니다')
            if r['version']!=version: raise Conflict('상품이 변경되었습니다. 재조회 후 삭제하세요')
            con.execute('DELETE FROM products WHERE id=?',(pid,))
            con.execute('INSERT INTO audit(action,sku,created) VALUES(?,?,?)',('판매자 승인 삭제',r['sku'],now()))
    def settings(self,data=None):
        with self.connect() as con:
            if data is not None: con.execute('INSERT OR REPLACE INTO settings VALUES(1,?)',(data.model_dump_json(),))
            row=con.execute('SELECT body FROM settings WHERE id=1').fetchone()
            return Settings.model_validate_json(row[0]) if row else Settings()
    def backup(self,path):
        with self.connect() as source, sqlite3.connect(path) as target: source.backup(target)
