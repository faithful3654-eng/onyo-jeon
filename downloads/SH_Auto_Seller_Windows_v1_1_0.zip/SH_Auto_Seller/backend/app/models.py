from datetime import datetime, timezone
from typing import Literal
from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode
from pydantic import BaseModel, ConfigDict, Field, field_validator
import hashlib
import json
import re


def now(): return datetime.now(timezone.utc).isoformat(timespec='seconds')

class Base(BaseModel):
    model_config=ConfigDict(extra='forbid',str_strip_whitespace=True,allow_inf_nan=False)

Money= float | None

class Product(Base):
    sku: str=Field(default='',max_length=60,pattern=r'^[A-Za-z0-9_-]*$')
    name: str=Field(min_length=1,max_length=300)
    supplier: str=Field(default='',max_length=200)
    source_url: str=Field(default='',max_length=2000)
    brand: str=Field(default='',max_length=100)
    purchase_krw: Money=Field(default=None,ge=0,le=1e12)
    domestic_shipping_krw: Money=Field(default=None,ge=0,le=1e12)
    options: str=Field(default='',max_length=1000)
    stock: int | None=Field(default=None,ge=0,le=1_000_000_000)
    image_urls: list[str]=Field(default_factory=list,max_length=30)
    image_rights_confirmed: bool=False
    description: str=Field(default='',max_length=30000)
    weight_kg: Money=Field(default=None,ge=0,le=10000)
    origin: str=Field(default='',max_length=100)
    manufacturer: str=Field(default='',max_length=200)
    category: str=Field(default='',max_length=100)
    collected_at: str=Field(default_factory=now,max_length=50)
    data_status: Literal['사용자 입력','공급처 파일','실제값','추정','데모','미수집']='사용자 입력'
    collection_method: str=Field(default='직접 입력',max_length=100)
    notes: str=Field(default='',max_length=2000)

    @field_validator('stock',mode='before')
    @classmethod
    def integer_stock(cls,value):
        if isinstance(value,bool): raise ValueError('재고에 참/거짓을 사용할 수 없습니다')
        return value

    @field_validator('source_url')
    @classmethod
    def url(cls,value):
        if value: clean_url(value)
        return value

    @field_validator('image_urls')
    @classmethod
    def images(cls,values):
        for value in values: clean_url(value)
        return values

    @field_validator('collected_at')
    @classmethod
    def date(cls,value):
        if not value: raise ValueError('수집일시 필수')
        datetime.fromisoformat(value.replace('Z','+00:00'))
        return value


def clean_url(value):
    p=urlsplit(value)
    if p.scheme not in {'https','http'} or not p.hostname or p.username or p.password:
        raise ValueError('인증정보가 없는 공개 http(s) 주소를 입력하세요')
    pairs=parse_qsl(p.query,keep_blank_values=True)
    sensitive={'token','access_token','api_key','apikey','password','passwd','secret','authorization','auth','session','sessionid','signature','x-amz-signature','x-amz-credential','x-goog-signature','key'}
    if any(k.lower() in sensitive for k,v in pairs): raise ValueError('토큰·비밀번호·인증키가 포함된 URL은 저장할 수 없습니다')
    pairs=sorted((k,v) for k,v in pairs if not k.lower().startswith('utm_'))
    return urlunsplit((p.scheme.lower(),p.netloc.lower(),p.path.rstrip('/'),urlencode(pairs),''))


def dedup_key(p):
    if not p.source_url: return None
    option=re.sub(r'\s+',' ',p.options.strip()).casefold()
    return hashlib.sha256(json.dumps([clean_url(p.source_url),option],ensure_ascii=False).encode()).hexdigest()


class ProductUpdate(Base):
    product: Product
    expected_version: int=Field(ge=1)

class DeleteRequest(Base):
    approved: bool=False
    expected_version: int=Field(ge=1)

class Settings(Base):
    exchange_krw_per_100_jpy: Money=Field(default=None,gt=0,le=1e6)
    platform_fee_pct: Money=Field(default=None,ge=0,lt=100)
    target_margin_pct: float=Field(default=25,ge=0,lt=100)
    international_shipping_krw: Money=Field(default=None,ge=0,le=1e12)
    packaging_krw: Money=Field(default=None,ge=0,le=1e12)
    tax_other_krw: Money=Field(default=None,ge=0,le=1e12)
    return_reserve_krw: Money=Field(default=None,ge=0,le=1e12)
    seller_coupon_jpy: Money=Field(default=None,ge=0,le=1e12)
    buyer_shipping_jpy: Money=Field(default=None,ge=0,le=1e12)
    settlement: Literal['상품+배송 수수료','상품만 수수료']='상품+배송 수수료'
    tax_basis: Literal['세전 추정','세금 입력 포함 추정']='세전 추정'
    paid_shipping: bool=True
    shipping_no: str=Field(default='818056',max_length=50,pattern=r'^\d*$')
    shipping_code_verified: bool=False

class MarginInput(Settings):
    purchase_krw: Money=Field(default=None,ge=0,le=1e12)
    domestic_shipping_krw: Money=Field(default=None,ge=0,le=1e12)
    sale_jpy: Money=Field(default=None,gt=0,le=1e12)

class PreviewRequest(Base):
    upload_id: str
    sheet: str
    mapping: dict[str,str]
    merge: bool=False

class CommitRequest(Base):
    batch_id: str
    approved: bool=False

FIELDS={
 'sku':'SKU','name':'상품명','supplier':'공급처명','source_url':'공급처 URL','brand':'브랜드',
 'purchase_krw':'매입가격(KRW)','domestic_shipping_krw':'국내배송비(KRW)','options':'옵션','stock':'옵션별 재고',
 'image_urls':'이미지 URL(줄바꿈 구분)','image_rights_confirmed':'이미지 사용권 확인','description':'상세설명',
 'weight_kg':'무게(kg)','origin':'원산지','manufacturer':'제조사','category':'카테고리','collected_at':'수집일시',
 'data_status':'데이터 상태','collection_method':'수집 방식','notes':'메모'}
ALIASES={
 'sku':['sku','판매자상품코드','상품코드','seller item code'],
 'name':['상품명','제품명','상품명(한글)','product name','name'],
 'supplier':['공급처명','공급처','supplier'],
 'source_url':['공급처 url','상품url','상품 url','url','source_url'],
 'brand':['브랜드','브랜드명','brand'],
 'purchase_krw':['매입가격(krw)','매입가','매입가격','원가','purchase_krw'],
 'domestic_shipping_krw':['국내배송비(krw)','국내배송비','domestic_shipping_krw'],
 'options':['옵션','옵션명','options'], 'stock':['재고','옵션별 재고','stock'],
 'image_urls':['이미지 url(줄바꿈 구분)','이미지','이미지url','image_urls'],
 'weight_kg':['무게(kg)','중량(kg)','weight_kg'],
}
for field,label in FIELDS.items(): ALIASES.setdefault(field,[field,label.lower()])
