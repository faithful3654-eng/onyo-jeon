from decimal import Decimal, ROUND_CEILING
from .models import MarginInput


def calculate(data: MarginInput):
    fields=['purchase_krw','domestic_shipping_krw','international_shipping_krw','packaging_krw',
            'tax_other_krw','return_reserve_krw','exchange_krw_per_100_jpy','platform_fee_pct','seller_coupon_jpy','buyer_shipping_jpy']
    missing=[f for f in fields if getattr(data,f) is None]
    result=dict(status='비용 추가 확인 필요' if missing else '입력 가정 기준 계산',missing=missing,
                recommended_jpy=None,breakeven_jpy=None,revenue_krw=None,total_cost_krw=None,contribution_krw=None,margin_pct=None,
                tax_basis=data.tax_basis,settlement=data.settlement,shipping_no=data.shipping_no if data.paid_shipping else None,
                shipping_code_status='판매자 확인 완료' if data.shipping_code_verified else '계정 사용 가능 여부 미확인',
                assumptions='매출=상품가격+구매자 배송비. 쿠폰은 비용, 수수료 기준은 설정을 따름. 반품 충당액은 판매 1건당 예상값. 세금·정산은 입력 가정이며 순이익 보장 아님.')
    if missing: return result
    d=lambda f: Decimal(str(getattr(data,f)))
    rate=d('exchange_krw_per_100_jpy')/100
    fee=d('platform_fee_pct')/100; target=d('target_margin_pct')/100
    if fee+target>=1: raise ValueError('수수료율과 목표 이익률의 합은 100% 미만이어야 합니다')
    if not data.paid_shipping and d('buyer_shipping_jpy')!=0: raise ValueError('무료배송은 구매자 배송비가 0이어야 합니다')
    fixed=sum(d(f) for f in ['purchase_krw','domestic_shipping_krw','international_shipping_krw','packaging_krw','tax_other_krw','return_reserve_krw'])
    coupon=d('seller_coupon_jpy')*rate
    shipping=d('buyer_shipping_jpy')*rate
    fee_shipping=shipping*fee if data.settlement=='상품+배송 수수료' else Decimal(0)
    def price_for(margin):
        # P*r*(1-fee-margin) >= fixed+coupon+fee_shipping-shipping*(1-margin)
        yen=(fixed+coupon+fee_shipping-shipping*(1-margin))/(rate*(1-fee-margin))
        return max(1,int(yen.to_integral_value(rounding=ROUND_CEILING)))
    result.update(recommended_jpy=price_for(target),breakeven_jpy=price_for(Decimal(0)))
    if data.sale_jpy is None:
        result['status']='판매가격 입력 시 예상 이익 계산'; return result
    sale=d('sale_jpy')*rate
    revenue=sale+shipping
    costs=fixed+coupon+sale*fee+fee_shipping
    contribution=revenue-costs
    result.update(revenue_krw=round(float(revenue),2),total_cost_krw=round(float(costs),2),
                  contribution_krw=round(float(contribution),2),margin_pct=round(float(contribution/revenue*100),4))
    return result
