"""Future official supplier adapters must return validated Product objects.
No network access is made in the phase-1 MVP.
"""
from typing import Protocol
from .models import Product

class SupplierAdapter(Protocol):
    name: str
    def collect(self,url:str)->list[Product]: ...

REGISTRY: dict[str,SupplierAdapter]={}

def capabilities():
    return {'manual':True,'excel':True,'csv':True,'supplier_api':False,'url_collection':False,
            'openai':False,'gemini':False,'qapi':False,'qsm_export':False,'dry_run':True,'qoo10_public_research':True,'daily_report_configuration':True,
            'message':'공급처 URL 수집·AI·QAPI 미연결. 별도 일일 리포트의 큐텐 공개 인기 목록 조회만 지원하며 메일 인증·Windows 예약 설정이 필요합니다.'}
