from pathlib import Path
from datetime import datetime,timedelta,timezone
import hashlib,os,subprocess,tempfile,re
from xml.etree import ElementTree as ET

KST=timezone(timedelta(hours=9))
NS='http://schemas.microsoft.com/windows/2004/02/mit/task'

def task_name(root): return 'SHAutoSeller_Daily_'+hashlib.sha256(str(Path(root).resolve()).encode()).hexdigest()[:12]

def task_xml(root,user_sid,at='09:00',clock=None):
    clock=clock or datetime.now(KST);hour,minute=map(int,at.split(':'))
    start=clock.astimezone(KST).replace(hour=hour,minute=minute,second=0,microsecond=0)
    if start<=clock: start+=timedelta(days=1)
    ET.register_namespace('',NS)
    task=ET.Element('{'+NS+'}Task',version='1.2')
    def child(parent,tag,text=None,**attrs):
        value=ET.SubElement(parent,tag,attrs)
        if text is not None:value.text=str(text)
        return value
    registration=child(task,'RegistrationInfo');child(registration,'Description','SH Auto Seller: Qoo10 public research report. Requires this user to be logged in.')
    trigger=child(child(task,'Triggers'),'CalendarTrigger');child(trigger,'StartBoundary',start.isoformat());child(trigger,'Enabled','true')
    child(child(trigger,'ScheduleByDay'),'DaysInterval','1')
    principal=child(child(task,'Principals'),'Principal',id='Author');child(principal,'UserId',user_sid);child(principal,'LogonType','InteractiveToken');child(principal,'RunLevel','LeastPrivilege')
    settings=child(task,'Settings')
    for name,value in [('MultipleInstancesPolicy','IgnoreNew'),('DisallowStartIfOnBatteries','false'),('StopIfGoingOnBatteries','false'),('StartWhenAvailable','true'),('RunOnlyIfNetworkAvailable','true'),('Enabled','true'),('WakeToRun','false'),('ExecutionTimeLimit','PT20M')]: child(settings,name,value)
    action=child(child(task,'Actions',Context='Author'),'Exec')
    root=Path(root).resolve();child(action,'Command',root/'.venv/Scripts/python.exe');child(action,'Arguments','"'+str(root/'daily_report.py')+'"');child(action,'WorkingDirectory',root)
    return ET.tostring(task,encoding='utf-16',xml_declaration=True)

def register(root,at='09:00'):
    if os.name!='nt': raise ValueError('Windows PC에서만 실제 예약을 등록할 수 있습니다. 클라우드에서는 예약하지 않았습니다.')
    who=subprocess.run(['whoami','/user','/fo','csv','/nh'],capture_output=True,check=True)
    match=re.search(rb'S-1-\d+(?:-\d+)+',who.stdout)
    if not match: raise ValueError('현재 Windows 사용자 식별자를 확인하지 못했습니다.')
    sid=match.group(0).decode('ascii')
    with tempfile.TemporaryDirectory(prefix='sh-report-task-') as td:
        path=Path(td)/'daily-task.xml';path.write_bytes(task_xml(root,sid,at))
        r=subprocess.run(['schtasks','/Create','/TN',task_name(root),'/XML',str(path),'/F'],capture_output=True)
    if r.returncode: raise ValueError('Windows 예약 등록 실패. 작업 스케줄러 접근 권한과 현재 실행 중인 Windows 계정을 확인하세요.')
    return task_name(root)

def remove(root):
    if os.name!='nt': raise ValueError('이 환경에는 Windows 예약 작업이 없습니다.')
    r=subprocess.run(['schtasks','/Delete','/TN',task_name(root),'/F'],capture_output=True)
    if r.returncode: raise ValueError('예약 해제 실패. Windows 작업 스케줄러에서 '+task_name(root)+' 항목을 확인하세요.')

def exists(root):
    if os.name!='nt': return False
    return subprocess.run(['schtasks','/Query','/TN',task_name(root)],capture_output=True).returncode==0
