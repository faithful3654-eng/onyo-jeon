import {defineConfig} from '@playwright/test';
import path from 'node:path';
const db=path.resolve('../data/e2e-'+Date.now()+'.sqlite3');
export default defineConfig({testDir:'./e2e',workers:1,timeout:45000,use:{baseURL:'http://127.0.0.1:8766',headless:true,viewport:{width:1440,height:1000},launchOptions:{...(process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE?{executablePath:process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE}:{}),args:['--no-sandbox']}},webServer:{command:'../.venv/bin/python -m uvicorn app.main:app --app-dir ../backend --host 127.0.0.1 --port 8766',url:'http://127.0.0.1:8766/api/health',reuseExistingServer:false,env:{SH_DB_PATH:db,SH_PORT:'8766'},timeout:30000}});
