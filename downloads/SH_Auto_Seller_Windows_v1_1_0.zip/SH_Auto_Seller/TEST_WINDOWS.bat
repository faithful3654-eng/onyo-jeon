@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  echo 먼저 START_WINDOWS.bat으로 설치하세요.
  pause
  exit /b 1
)
.venv\Scripts\python.exe -m pytest -q
if errorlevel 1 (
  pause
  exit /b 1
)
echo 백엔드 테스트가 통과했습니다.
pause
