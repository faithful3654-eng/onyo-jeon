"""Windows Task Scheduler entrypoint; does not require the web server to run."""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'backend'))
from app.main import create_app

def main():
    service=create_app().state.reports
    if not service.config().get('enabled'):
        print('일일 메일 예약이 비활성 상태입니다. 발송하지 않았습니다.');return
    run_id,fresh=service.claim('daily')
    if not fresh:
        print('오늘 작업이 이미 있습니다. 중복 발송하지 않았습니다.');return
    service.perform(run_id,True)
    row=next(r for r in service.runs() if r['id']==run_id)
    print('일일 메일 작업 상태:',row['state'])
    if row['state']!='sent':sys.exit(1)

if __name__=='__main__':main()
