"""Runtime selection and repeatable installation using only the standard library."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import struct
import subprocess
import sys
import sysconfig
import uuid
from datetime import datetime

PYTHON_HELP=('Windows에서는 Python 3.12 64비트가 필요합니다.\n'
             'https://www.python.org/ftp/python/3.12.10/python-3.12.10-amd64.exe\n'
             '설치 화면에서 Add python.exe to PATH와 Python Launcher를 선택한 뒤 다시 실행하세요.\n'
             '다른 버전의 Python을 삭제하거나 Visual Studio/Rust를 설치할 필요는 없습니다.')
PROBE="import sys,sysconfig,struct,json;print(json.dumps(dict(version=list(sys.version_info[:2]),bits=struct.calcsize('P')*8,implementation=sys.implementation.name,platform=sysconfig.get_platform(),executable=sys.executable)))"


def current_runtime():
    return dict(version=list(sys.version_info[:2]),bits=struct.calcsize('P')*8,
                implementation=sys.implementation.name,platform=sysconfig.get_platform(),executable=sys.executable)


def supported(info,windows):
    if not info or info.get('implementation')!='cpython': return False
    if windows:
        return info.get('version')==[3,12] and info.get('bits')==64 and info.get('platform')=='win-amd64'
    return [3,11]<=info.get('version',[])<[3,15]


def inspect_runtime(command):
    try:
        p=subprocess.run([str(x) for x in command]+['-c',PROBE],capture_output=True,text=True,timeout=15)
        if p.returncode: return None
        return json.loads(p.stdout.strip())
    except (OSError,ValueError,subprocess.SubprocessError): return None


def find_windows_python(probe=inspect_runtime):
    # Never choose the latest `py -3` blindly: it may be unsupported by native wheels.
    for command in [['py','-3.12-64'],['py','-3.12'],['python3.12'],['python']]:
        info=probe(command)
        if supported(info,True): return info['executable']
    return None


def ensure_supported_launcher(root):
    windows=os.name=='nt'
    info=current_runtime()
    if supported(info,windows): return
    if windows:
        executable=find_windows_python()
        if executable:
            print('설치된 Python 3.12 64비트로 전환합니다.',flush=True)
            raise SystemExit(subprocess.call([executable,str(Path(root)/'launcher.py'),*sys.argv[1:]],cwd=root))
        raise RuntimeError(PYTHON_HELP)
    raise RuntimeError('이 실행기는 CPython 3.11~3.14에서 지원합니다. Python 3.12를 권장합니다.')


def ensure_venv(root,creator,windows=None,probe=inspect_runtime,runner=subprocess.run):
    root=Path(root);windows=os.name=='nt' if windows is None else windows
    venv=root/'.venv';python=venv/('Scripts/python.exe' if windows else 'bin/python')
    if venv.exists() and not supported(probe([python]) if python.exists() else None,windows):
        backup=root/('.venv-backup-'+datetime.now().strftime('%Y%m%d-%H%M%S')+'-'+uuid.uuid4().hex[:6])
        try: venv.rename(backup)
        except OSError as exc: raise RuntimeError('기존 실행 환경을 옮길 수 없습니다. 실행 중인 프로그램 콘솔을 닫고 다시 실행하세요.') from exc
        print('호환되지 않는 실행 환경을 보존했습니다: '+backup.name,flush=True)
    if not python.exists():
        print('[1/3] 호환되는 전용 Python 실행 환경을 만듭니다.',flush=True)
        runner([str(creator),'-m','venv',str(venv)],check=True,cwd=root)
    return python


def install_plan(root,python,windows=None):
    root=Path(root);windows=os.name=='nt' if windows is None else windows
    requirements=root/'backend'/('requirements-windows.lock' if windows else 'requirements.lock')
    # A new installer version invalidates markers from an earlier source-build attempt.
    fingerprint=hashlib.sha256(b'binary-bootstrap-v2\n'+requirements.read_bytes()).hexdigest()
    command=[str(python),'-m','pip','install','--disable-pip-version-check','--only-binary=:all:','-r',str(requirements)]
    if windows:
        command+=['--require-hashes']
        wheelhouse=root/'windows_wheels'
        if wheelhouse.is_dir(): command+=['--no-index','--find-links',str(wheelhouse)]
        else: command+=['--index-url','https://pypi.org/simple']
    command+=['--cache-dir',str(root/'data'/'pip-cache')]
    return command,fingerprint
